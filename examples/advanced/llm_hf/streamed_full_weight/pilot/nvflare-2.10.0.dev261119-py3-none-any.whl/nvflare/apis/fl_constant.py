# Copyright (c) 2021, NVIDIA CORPORATION.  All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from enum import Enum

# Server-to-CLI protocol value used in job metadata to signal that a retry-safe
# submit token conflicts with an existing submission.
SUBMIT_TOKEN_CONFLICT_STATUS = "submit_token_conflict"

# Server-to-CLI protocol value used when a retry-safe submit token points to a job
# that was deliberately deleted.
SUBMIT_TOKEN_JOB_DELETED_STATUS = "submit_token_job_deleted"


class ReturnCode:

    OK = "OK"

    BAD_PEER_CONTEXT = "BAD_PEER_CONTEXT"
    BAD_REQUEST_DATA = "BAD_REQUEST_DATA"
    BAD_TASK_DATA = "BAD_TASK_DATA"
    COMMUNICATION_ERROR = "COMMUNICATION_ERROR"
    TIMEOUT = "TIMEOUT"
    ERROR = "ERROR"
    EXECUTION_EXCEPTION = "EXECUTION_EXCEPTION"
    EXECUTION_RESULT_ERROR = "EXECUTION_RESULT_ERROR"
    HANDLER_EXCEPTION = "HANDLER_EXCEPTION"
    MISSING_PEER_CONTEXT = "MISSING_PEER_CONTEXT"
    RUN_MISMATCH = "RUN_MISMATCH"
    TASK_ABORTED = "TASK_ABORTED"
    TASK_DATA_FILTER_ERROR = "TASK_DATA_FILTER_ERROR"
    TASK_RESULT_FILTER_ERROR = "TASK_RESULT_FILTER_ERROR"
    TASK_UNKNOWN = "TASK_UNKNOWN"
    TASK_UNSUPPORTED = "TASK_UNSUPPORTED"
    TOPIC_UNKNOWN = "TOPIC_UNKNOWN"
    MODEL_UNRECOGNIZED = "MODEL_UNRECOGNIZED"
    VALIDATE_TYPE_UNKNOWN = "VALIDATE_TYPE_UNKNOWN"
    EMPTY_RESULT = "EMPTY_RESULT"
    UNSAFE_JOB = "UNSAFE_JOB"
    EARLY_TERMINATION = "EARLY_TERMINATION"
    SERVER_NOT_READY = "SERVER_NOT_READY"
    SERVICE_UNAVAILABLE = "SERVICE_UNAVAILABLE"


class MachineStatus(Enum):
    """Constants for machine status.

    Status Lifecycle
        STOPPED <-> STARTING -> STARTED -> STOPPING -> STOPPED
    """

    STARTING = "starting"
    STARTED = "started"
    STOPPING = "stopping"
    STOPPED = "stopped"


class ReservedKey:

    MANAGER = "__manager__"
    ENGINE = "__engine__"
    AUX_RUNNER = "__aux_runner__"
    RUN_NUM = "__run_num__"
    IDENTITY_NAME = "__identity_name__"  # identity of the endpoint (e.g. client name)
    FQSN = "__fqsn__"
    IS_LEAF = "__is_leaf__"
    PEER_CTX = "__peer_ctx__"
    RC = "__rc__"
    COOKIE_JAR = "__cookie_jar__"
    WORKSPACE_ROOT = "__workspace_root__"
    APP_ROOT = "__app_root__"
    CLIENT_NAME = "__client_name__"
    CLIENT_TYPE = "__client_type__"
    TASK_NAME = "__task_name__"
    TASK_DATA = "__task_data__"
    TASK_RESULT = "__task_result__"
    TASK_ID = "__task_id__"
    TASK_ATTEMPT_ID = "__task_attempt_id__"
    TASK_ATTEMPT_REQUIRED = "__task_attempt_required__"
    EVENT_ID = "__event_id__"
    AUDIT_EVENT_ID = "__audit_event_id__"
    IS_RESEND = "__is_resend__"
    RUNNER = "__runner__"
    WORKFLOW = "__workflow__"
    REPLY = "__reply__"
    EVENT_ORIGIN = "__event_origin__"
    EVENT_ORIGIN_SITE = "__event_origin_site__"
    EVENT_DATA = "__event_data__"
    EVENT_SCOPE = "__event_scope__"
    RUN_ABORT_SIGNAL = "__run_abort_signal__"
    RUN_ABORT_REQUESTED = "__run_abort_requested__"
    SHAREABLE = "__shareable__"
    SHARED_FL_CONTEXT = "__shared_fl_context__"
    ARGS = "__args__"
    WORKSPACE_OBJECT = "__workspace_object__"
    RANK_NUMBER = "__rank_number__"
    NUM_OF_PROCESSES = "__num_of_processes__"
    FROM_RANK_NUMBER = "__from_rank_number__"
    SECURE_MODE = "__secure_mode__"
    SIMULATE_MODE = "__simulate_mode__"
    JOB_INFO = "__job_info__"
    JOB_META = "__job_meta__"
    CURRENT_JOB_ID = "__current_job_id__"
    JOB_RUN_NUMBER = "__job_run_number__"
    JOB_DEPLOY_DETAIL = "__job_deploy_detail__"
    FATAL_SYSTEM_ERROR = "__fatal_system_error__"
    JOB_IS_UNSAFE = "__job_is_unsafe__"
    CUSTOM_PROPS = "__custom_props__"
    EXCEPTIONS = "__exceptions__"
    PROCESS_TYPE = "__process_type__"  # type of the current process (SP, CP, SJ, CJ)
    JOB_PROCESS_ARGS = "__job_process_args__"
    TASK_IS_READY = "__task_is_ready__"


class FLContextKey:

    TASK_NAME = ReservedKey.TASK_NAME
    TASK_DATA = ReservedKey.TASK_DATA
    TASK_RESULT = ReservedKey.TASK_RESULT
    TASK_RESULT_SEND_SUCCESS = "__task_result_send_success__"
    TASK_RESULT_SUBMISSION_ATTEMPTED = "__task_result_submission_attempted__"
    TASK_RESULT_RECEIPT = "__task_result_receipt__"
    TASK_RESULT_IS_LATE = "__task_result_is_late__"
    TASK_ID = ReservedKey.TASK_ID
    TASK_ATTEMPT_ID = ReservedKey.TASK_ATTEMPT_ID
    TASK_ATTEMPT_REQUIRED = ReservedKey.TASK_ATTEMPT_REQUIRED
    EVENT_ID = ReservedKey.EVENT_ID
    EVENT_ORIGIN = ReservedKey.EVENT_ORIGIN
    EVENT_ORIGIN_SITE = ReservedKey.EVENT_ORIGIN_SITE
    EVENT_DATA = ReservedKey.EVENT_DATA
    EVENT_SCOPE = ReservedKey.EVENT_SCOPE
    EXCEPTIONS = ReservedKey.EXCEPTIONS
    CLIENT_NAME = ReservedKey.CLIENT_NAME
    CLIENT_TYPE = ReservedKey.CLIENT_TYPE
    WORKSPACE_ROOT = ReservedKey.WORKSPACE_ROOT
    CURRENT_RUN = ReservedKey.RUN_NUM
    APP_ROOT = ReservedKey.APP_ROOT
    PEER_CONTEXT = ReservedKey.PEER_CTX
    IS_CLIENT_TASK_RESEND = ReservedKey.IS_RESEND
    RUNNER = ReservedKey.RUNNER
    WORKFLOW = ReservedKey.WORKFLOW
    SHAREABLE = ReservedKey.SHAREABLE
    RUN_ABORT_SIGNAL = ReservedKey.RUN_ABORT_SIGNAL
    RUN_ABORT_REQUESTED = ReservedKey.RUN_ABORT_REQUESTED
    ARGS = ReservedKey.ARGS
    REPLY = ReservedKey.REPLY
    WORKSPACE_OBJECT = ReservedKey.WORKSPACE_OBJECT
    RANK_NUMBER = ReservedKey.RANK_NUMBER
    NUM_OF_PROCESSES = ReservedKey.NUM_OF_PROCESSES
    FROM_RANK_NUMBER = ReservedKey.FROM_RANK_NUMBER
    SECURE_MODE = ReservedKey.SECURE_MODE
    SIMULATE_MODE = ReservedKey.SIMULATE_MODE
    JOB_INFO = ReservedKey.JOB_INFO
    JOB_META = ReservedKey.JOB_META
    CURRENT_JOB_ID = ReservedKey.CURRENT_JOB_ID
    JOB_RUN_NUMBER = ReservedKey.JOB_RUN_NUMBER
    JOB_DEPLOY_DETAIL = ReservedKey.JOB_DEPLOY_DETAIL
    CUSTOM_PROPS = ReservedKey.CUSTOM_PROPS
    JOB_SCOPE_NAME = "__job_scope_name__"
    EFFECTIVE_JOB_SCOPE_NAME = "__effective_job_scope_name__"
    SCOPE_PROPERTIES = "__scope_props__"
    SCOPE_OBJECT = "__scope_object__"
    FATAL_SYSTEM_ERROR = ReservedKey.FATAL_SYSTEM_ERROR
    COMMUNICATION_ERROR = "Flare_communication_error__"
    UNAUTHENTICATED = "Flare_unauthenticated__"
    CLIENT_RESOURCE_SPECS = "__client_resource_specs"
    ALLOCATED_RESOURCES = "__allocated_resources"
    RESOURCE_CHECK_RESULT = "__resource_check_result"
    JOB_PARTICIPANTS = "__job_participants"
    JOB_BLOCK_REASON = "__job_block_reason"  # why the job should be blocked from scheduling
    SSID = "__ssid__"
    CLIENT_TOKEN = "__client_token"
    AUTHORIZATION_RESULT = "_authorization_result"
    AUTHORIZATION_REASON = "_authorization_reason"
    DISCONNECTED_CLIENT_NAME = "_disconnected_client_name"
    RECONNECTED_CLIENT_NAME = "_reconnected_client_name"
    SITE_OBJ = "_site_obj_"
    JOB_LAUNCHER = "_job_launcher"
    JOB_HANDLE_CALLBACK = "_job_handle_callback"
    JOB_RESTART_HANDLE = "_job_restart_handle"  # Confirmed previous execution, only during replacement launch.
    SNAPSHOT = "job_snapshot"

    CLIENT_REGISTER_DATA = "_client_register_data"
    SECURITY_ITEMS = "_security_items"
    COMMAND_NAME = "_command_name"
    SITE_NAME = "__site_name"
    USER_NAME = "__user_name"
    USER_ORG = "__user_org"
    USER_ROLE = "__user_role"
    SUBMITTER_NAME = "_submitterName"
    SUBMITTER_ORG = "_submitterOrg"
    SUBMITTER_ROLE = "_submitterRole"
    COMPONENT_BUILD_ERROR = "__component_build_error__"
    COMPONENT_CONFIG = "__component_config__"
    COMPONENT_NODE = "__component_node__"
    CONFIG_CTX = "__config_ctx__"
    FILTER_DIRECTION = "__filter_dir__"
    ROOT_URL = "__root_url__"  # the URL for accessing the FL Server
    NOT_READY_TO_END_RUN = "not_ready_to_end_run__"  # component sets this to indicate it's not ready to end run yet
    CLIENT_CONFIG = "__client_config__"
    SERVER_CONFIG = "__server_config__"
    CLIENT_SITE_CONFIG = "__client_site_config__"
    SERVER_HOST_NAME = "__server_host_name__"
    PROCESS_TYPE = ReservedKey.PROCESS_TYPE
    JOB_PROCESS_ARGS = ReservedKey.JOB_PROCESS_ARGS
    EVENT_PROCESSED = "__event_processed__"
    CELL_MESSAGE = "__cell_message__"
    CLIENT_HIERARCHY = "__client_hierarchy__"

    # Tensor streaming: minimum get_task_timeout required by server (stored in FLContext)
    MIN_GET_TASK_TIMEOUT = "__min_get_task_timeout__"


class ProcessType:
    SERVER_PARENT = "SP"
    SERVER_JOB = "SJ"
    CLIENT_PARENT = "CP"
    CLIENT_JOB = "CJ"


class ReservedTopic:

    END_RUN = "__end_run__"
    ABORT_ASK = "__abort_task__"
    DO_TASK = "__do_task__"
    AUX_COMMAND = "__aux_command__"
    SYNC_RUNNER = "__sync_runner__"
    JOB_HEART_BEAT = "__job_heartbeat__"
    TASK_CHECK = "__task_check__"
    APP_METRICS = "__app_metrics__"
    MSG_ROOT_DELETED = "__msg_root_deleted__"
    STOP_CELLNET = "__stop_cellnet__"


JOB_CLONE_DEPRECATION_MESSAGE = (
    "Job cloning is deprecated. Cloning preserves the original signing certificate and its expiration; it does not "
    "renew or replace the certificate. Re-export or reuse the original local job folder and submit it with current "
    "credentials using 'nvflare job submit -j JOB_FOLDER' so the artifact is signed with the current submitter "
    "certificate."
)


class AdminCommandNames:

    REGISTER_STUDY = "register_study"
    ADD_STUDY_SITE = "add_study_site"
    REMOVE_STUDY_SITE = "remove_study_site"
    REMOVE_STUDY = "remove_study"
    LIST_STUDIES = "list_studies"
    SHOW_STUDY = "show_study"
    ADD_STUDY_USER = "add_study_user"
    REMOVE_STUDY_USER = "remove_study_user"
    SUBMIT_JOB = "submit_job"
    LIST_JOBS = "list_jobs"
    GET_JOB_META = "get_job_meta"
    LIST_JOB = "list_job"
    DOWNLOAD_JOB = "download_job"
    DOWNLOAD_JOB_COMPONENTS = "download_job_components"
    ABORT_JOB = "abort_job"
    DELETE_JOB = "delete_job"
    CLONE_JOB = "clone_job"
    DELETE_WORKSPACE = "delete_workspace"
    CHECK_RESOURCES = "check_resources"
    DEPLOY_APP = "deploy_app"
    CHECK_STATUS = "check_status"
    ADMIN_CHECK_STATUS = "admin_check_status"
    ABORT = "abort"
    ABORT_TASK = "abort_task"
    REMOVE_CLIENT = "remove_client"
    DISABLE_CLIENT = "disable_client"
    ENABLE_CLIENT = "enable_client"
    SHUTDOWN = "shutdown"
    RESTART = "restart"
    SET_TIMEOUT = "set_timeout"
    SHOW_STATS = "show_stats"
    SHOW_ERRORS = "show_errors"
    RESET_ERRORS = "reset_errors"
    GET_JOB_LOG = "get_job_log"
    AUX_COMMAND = "aux_command"
    SYS_INFO = "sys_info"
    REPORT_RESOURCES = "report_resources"
    REPORT_ENV = "report_env"
    REPORT_VERSION = "report_version"
    SHOW_SCOPES = "show_scopes"
    CALL = "call"
    SHELL_PWD = "pwd"
    SHELL_LS = "ls"
    SHELL_CAT = "cat"
    SHELL_HEAD = "head"
    SHELL_TAIL = "tail"
    SHELL_GREP = "grep"
    APP_COMMAND = "app_command"
    GET_JOB_LOG = "get_job_log"
    CONFIGURE_JOB_LOG = "configure_job_log"
    CONFIGURE_SITE_LOG = "configure_site_log"


class ServerCommandNames:

    GET_RUN_INFO = "get_run_info"
    GET_TASK = "get_task"
    SUBMIT_UPDATE = "submit_update"
    AUX_COMMUNICATE = "aux_communicate"
    HEARTBEAT = "heartbeat"
    GET_CLIENTS = "get_clients"
    AUX_SEND = "aux_send"
    SHOW_STATS = "show_stats"
    GET_ERRORS = "get_errors"
    RESET_ERRORS = "reset_errors"
    UPDATE_RUN_STATUS = "update_run_status"
    HANDLE_DEAD_JOB = "handle_dead_job"
    SERVER_STATE = "server_state"
    APP_COMMAND = "app_command"


class ServerCommandKey:

    COMMAND = "command"
    DATA = "data"
    FL_CONTEXT = "fl_context"
    PEER_FL_CONTEXT = FLContextKey.PEER_CONTEXT
    SHAREABLE = "shareable"
    TASK_NAME = "task_name"
    TASK_ID = "task_id"
    LAST_TASK_ID = "last_task_id"
    FL_CLIENT = "fl_client"
    TOPIC = "topic"
    AUX_REPLY = "aux_reply"
    JOB_ID = "job_id"
    CLIENTS = "clients"
    COLLECTOR = "collector"
    TURN_TO_COLD = "__turn_to_cold__"
    REASON = "reason"
    MIN_GET_TASK_TIMEOUT = "min_get_task_timeout"


class FedEventHeader:

    TIMESTAMP = "_timestamp"
    EVENT_ID = "_event_id"
    EVENT_TYPE = "_event_type"
    DIRECTION = "_direction"
    ORIGIN = "_origin"
    TARGETS = "_targets"


class EventScope:

    FEDERATION = "federation"
    LOCAL = "local"


class NonSerializableKeys:

    KEYS = [
        ReservedKey.ENGINE,
        ReservedKey.MANAGER,
        ReservedKey.RUNNER,
        FLContextKey.SCOPE_PROPERTIES,
        FLContextKey.SCOPE_OBJECT,
        FLContextKey.CLIENT_HIERARCHY,
        FLContextKey.WORKSPACE_OBJECT,
        FLContextKey.TASK_DATA,
        FLContextKey.SHAREABLE,
    ]


class LogMessageTag:

    DEBUG = "log/debug"
    ERROR = "log/error"
    EXCEPTION = "log/exception"
    INFO = "log/info"
    WARNING = "log/warning"
    CRITICAL = "log/critical"
    LOG_RECORD = "log_record"


class SnapshotKey:

    FL_CONTEXT = "fl_context"
    SERVER_RUNNER = "_Server_Runner"
    WORKSPACE = "_workspace"
    JOB_INFO = "_job_info"
    JOB_ID = "_job_id"
    JOB_CLIENTS = "_job_clients"


class RunProcessKey:
    LISTEN_PORT = "_listen_port"
    CONNECTION = "_conn"
    JOB_HANDLE = "_job_launcher"
    STATUS = "_status"
    JOB_ID = "_job_id"
    PARTICIPANTS = "_participants"
    PROCESS_FINISHED = "_process_finished"
    PROCESS_EXE_ERROR = "_process_exe_error"
    PROCESS_RETURN_CODE = "_process_return_code"


class SystemComponents:

    JOB_SCHEDULER = "job_scheduler"
    JOB_MANAGER = "job_manager"
    JOB_RUNNER = "job_runner"
    SERVER_RUNNER = "server_runner"
    CLIENT_RUNNER = "client_runner"
    CHECK_RESOURCE_PROCESSOR = "check_resource_processor"
    CANCEL_RESOURCE_PROCESSOR = "cancel_resource_processor"
    RESOURCE_MANAGER = "resource_manager"
    RESOURCE_CONSUMER = "resource_consumer"
    APP_DEPLOYER = "app_deployer"
    DEFAULT_APP_DEPLOYER = "default_app_deployer"
    JOB_META_VALIDATOR = "job_meta_validator"
    FED_CLIENT = "fed_client"
    RUN_MANAGER = "run_manager"


class JobConstants:
    SERVER_JOB_CONFIG = "config_fed_server.json"
    CLIENT_JOB_CONFIG = "config_fed_client.json"
    META_FILE = "meta.json"
    META = "meta"
    SITES = "sites"
    JOB_IMAGE = "image"
    JOB_ID = "job_id"
    JOB_LAUNCHER = "job_launcher"


class WorkspaceConstants:
    """hard coded file names inside the workspace folder."""

    STARTUP_FOLDER_NAME = "startup"
    SITE_FOLDER_NAME = "local"
    CUSTOM_FOLDER_NAME = "custom"

    LOGGING_CONFIG = "log_config.json"
    DEFAULT_LOGGING_CONFIG = LOGGING_CONFIG + ".default"
    AUDIT_LOG = "audit.jsonl"
    LOG_FILE_NAME = "log.txt"
    ERROR_LOG_FILE_NAME = "error_log.txt"
    STATS_POOL_SUMMARY_FILE_NAME = "stats_pool_summary.json"
    STATS_POOL_RECORDS_FILE_NAME = "stats_pool_records.csv"

    # these two files is used by shell scripts to determine restart / shutdown
    RESTART_FILE = "restart.fl"
    SHUTDOWN_FILE = "shutdown.fl"

    WORKSPACE_PREFIX = ""
    APP_PREFIX = "app_"

    SERVER_STARTUP_CONFIG = "fed_server.json"
    CLIENT_STARTUP_CONFIG = "fed_client.json"
    ADMIN_STARTUP_CONFIG = "fed_admin.json"

    SERVER_APP_CONFIG = JobConstants.SERVER_JOB_CONFIG
    CLIENT_APP_CONFIG = JobConstants.CLIENT_JOB_CONFIG

    JOB_META_FILE = "meta.json"

    AUTHORIZATION_CONFIG = "authorization.json"
    DEFAULT_AUTHORIZATION_CONFIG = AUTHORIZATION_CONFIG + ".default"
    RESOURCES_CONFIG = "resources.json"
    DEFAULT_RESOURCES_CONFIG = RESOURCES_CONFIG + ".default"
    PRIVACY_CONFIG = "privacy.json"
    SAMPLE_PRIVACY_CONFIG = PRIVACY_CONFIG + ".sample"
    JOB_RESOURCES_CONFIG = "job_resources.json"
    STUDY_REGISTRY_CONFIG = "study_registry.json"

    ADMIN_STARTUP_CONFIG = "fed_admin.json"

    RESOURCE_FILE_NAME_PATTERN = "*__resources.json"  # for both parent and job processes
    JOB_RESOURCE_FILE_NAME_PATTERN = "*__j_resources.json"  # for job process only
    PARENT_RESOURCE_FILE_NAME_PATTERN = "*__p_resources.json"  # for parent process only

    ENV_VAR_RESULT_ROOT = "NVFL_RESULT_ROOT"
    ENV_VAR_LOG_ROOT = "NVFL_LOG_ROOT"
    ENV_VAR_AUDIT_ROOT = "NVFL_AUDIT_ROOT"


class SiteType:
    SERVER = "server"
    SERVER_PARENT = "server_parent"
    CLIENT = "client"
    ALL = "@ALL"


class SystemConfigs:
    STARTUP_CONF = "start_config"
    RESOURCES_CONF = "resources_config"
    APPLICATION_CONF = "application_config"


class SecureTrainConst:
    SSL_ROOT_CERT = "ssl_root_cert"
    SSL_CERT = "ssl_cert"
    PRIVATE_KEY = "ssl_private_key"


class FLMetaKey:
    NUM_STEPS_CURRENT_ROUND = "NUM_STEPS_CURRENT_ROUND"
    PROCESSED_ALGORITHM = "PROCESSED_ALGORITHM"
    PROCESSED_KEYS = "PROCESSED_KEYS"
    INITIAL_METRICS = "initial_metrics"
    FILTER_HISTORY = "filter_history"
    CONFIGS = "configs"
    VALIDATE_TYPE = "validate_type"
    START_ROUND = "start_round"
    CURRENT_ROUND = "current_round"
    TOTAL_ROUNDS = "total_rounds"
    JOB_ID = "job_id"
    SITE_NAME = "site_name"
    PROCESS_RC_FILE = "_process_rc.txt"
    SUBMIT_MODEL_NAME = "submit_model_name"
    AUTH_TOKEN = "auth_token"
    AUTH_TOKEN_SIGNATURE = "auth_token_signature"


class CellMessageAuthHeaderKey:
    CLIENT_NAME = "client_name"
    SSID = "ssid"
    TOKEN = "__token__"
    TOKEN_SIGNATURE = "__token_signature__"


class StreamCtxKey:
    JOB_ID = "job_id"
    CLIENT_NAME = "client_name"
    LOG_TYPE = "log_type"


class FilterKey:
    IN = "in"
    OUT = "out"
    INOUT = "inout"
    DELIMITER = "/"


class TaskResultReceipt:
    """Submission acknowledgement, independent of aggregation policy."""

    RECEIVED = "RECEIVED"
    TASK_CLOSED = "TASK_CLOSED"
    RETRY = "RETRY"


class ConfigVarName:
    TASK_RESULT_HISTORY_SIZE = "task_result_history_size"  # server: retired assignments retained per workflow
    # These variables can be set in job config files (config_fed_server or config_fed_client)
    RUNNER_SYNC_TIMEOUT = "runner_sync_timeout"  # client: runner sync message timeout
    MAX_RUNNER_SYNC_TIMEOUT = "max_runner_sync_timeout"  # client: max timeout of runner sync attempts
    TASK_CHECK_TIMEOUT = "task_check_timeout"  # client: timeout for task_check message (before submitting task)

    # client: how long to wait before sending task_check again (if previous task_check fails)
    TASK_CHECK_INTERVAL = "task_check_interval"

    # client: how often to send job heartbeats
    JOB_HEARTBEAT_INTERVAL = "job_heartbeat_interval"

    # client and server: max time to wait for components to become ready for end-run
    END_RUN_READINESS_TIMEOUT = "end_run_readiness_timeout"

    # client and server: how long to wait before checking components end-run readiness again (if previous check fails)
    END_RUN_READINESS_CHECK_INTERVAL = "end_run_readiness_check_interval"

    # client: timeout for getTask requests
    GET_TASK_TIMEOUT = "get_task_timeout"

    # client: timeout for submitTaskResult requests
    SUBMIT_TASK_RESULT_TIMEOUT = "submit_task_result_timeout"

    # client and server: max number of request workers for reliable message
    RM_MAX_REQUEST_WORKERS = "rm_max_request_workers"

    # client and server: query interval for reliable message
    RM_QUERY_INTERVAL = "rm_query_interval"

    # server: wait this long since client death report before treating the client as dead/disconnected
    DEAD_CLIENT_GRACE_PERIOD = "dead_client_grace_period"

    # server: wait this long since job schedule time before starting to check dead/disconnected clients
    DEAD_CLIENT_CHECK_LEAD_TIME = "dead_client_check_lead_time"

    # server: require all start-job replies to be non-timeout and OK before considering the run started
    STRICT_START_JOB_REPLY_CHECK = "strict_start_job_reply_check"

    # server: require prior positive job observation before reporting "missing job on client" as dead-job
    SYNC_CLIENT_JOBS_REQUIRE_PREVIOUS_REPORT = "sync_client_jobs_require_previous_report"

    # server: max time to wait for client terminal outcomes after the server process exits
    CLIENT_OUTCOME_WAIT_TIMEOUT = "client_outcome_wait_timeout"

    # server: validity in days of the per-job certificates issued at job deploy
    JOB_CERT_VALID_DAYS = "job_cert_valid_days"

    # customized nvflare decomposers module name
    DECOMPOSER_MODULE = "nvflare_decomposers"

    # client and server: max amount of time to wait for communication cell to be created
    CELL_WAIT_TIMEOUT = "cell_wait_timeout"

    # these vars are set in Server's startup config (fed_server.json)
    MAX_REG_DURATION = "max_reg_duration"

    # CJ: timeout for status notification message from CJ to CP
    NOTIFY_CP_MSG_TIMEOUT = "notify_cp_msg_timeout"

    # CJ: timeout for retrying status notification message from CJ to CP
    NOTIFY_CP_RETRY_TIMEOUT = "notify_cp_retry_timeout"

    # SJ and CJ: per-msg timeout for streaming
    STREAMING_PER_REQUEST_TIMEOUT = "streaming_per_request_timeout"

    # SJ and CJ: chunk size for downloading
    DOWNLOAD_CHUNK_SIZE = "download_chunk_size"

    # SJ and CJ: minimum transaction lifetime for large-tensor downloads.
    # Raise via job config when model size or network latency exceeds the default 60s.
    # Example: recipe.add_client_config({"np_min_download_timeout": 600.0})
    MIN_DOWNLOAD_TIMEOUT = "min_download_timeout"

    # SJ and CJ: min file size for streaming. If file size is less than this, it will be attached to msg directly.
    MIN_FILE_SIZE_FOR_STREAMING = "min_file_size_for_streaming"


class SystemVarName:
    """
    These vars are automatically generated by FLARE and can be referenced in job config (config_fed_client and
    config_fed_server). For example, you can reference SITE_NAME as "{SITE_NAME}" in your config.

    To avoid potential conflict with user-defined var names, these var names are in UPPER CASE.
    """

    SITE_NAME = "SITE_NAME"  # name of client site or server
    WORKSPACE = "WORKSPACE"  # directory of the workspace
    JOB_ID = "JOB_ID"  # Job ID
    ROOT_URL = "ROOT_URL"  # the URL of the Service Provider (server)
    CP_URL = "CP_URL"  # URL to CP
    RELAY_URL = "RELAY_URL"  # URL to relay that the CP is connected to
    SECURE_MODE = "SECURE_MODE"  # whether the system is running in secure mode
    JOB_CUSTOM_DIR = "JOB_CUSTOM_DIR"  # custom dir of the job
    JOB_CONFIG_DIR = "JOB_CONFIG_DIR"  # custom dir of the job
    PYTHONPATH = "PYTHONPATH"


class RunnerTask:

    INIT = "init"
    TASK_EXEC = "task_exec"
    END_RUN = "end_run"


class ConnPropKey:
    FQCN = "fqcn"
    IDENTITY = "identity"
    AUTH_IDENTITY = "auth_identity"
    AUTH_IDENTITY_MAP = "auth_identity_map"
    URL = "url"
    SCHEME = "scheme"
    ADDRESS = "address"
    CONNECTION_SECURITY = "connection_security"

    RELAY_CONFIG = "relay_config"
    CP_CONN_PROPS = "cp_conn_props"
    RELAY_CONN_PROPS = "relay_conn_props"
    ROOT_CONN_PROPS = "root_conn_props"


class ConnectionSecurity:
    CLEAR = "clear"
    TLS = "tls"
    MTLS = "mtls"
