# Copyright (c) 2022, NVIDIA CORPORATION.  All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from abc import ABC, abstractmethod
from typing import Any

from nvflare.apis.fl_component import FLComponent
from nvflare.apis.fl_context import FLContext
from nvflare.apis.job_def import Job, RunStatus, SubmitRecordState


class JobDefManagerSpec(FLComponent, ABC):
    """Job Definition Management API."""

    def job_exists(self, jid: str, fl_ctx: FLContext) -> bool:
        """Return authoritative job presence for interrupted log deletion.

        Custom managers may implement this optional method using a storage
        provider's authoritative presence check. Return a bool only when the
        result is certain; propagate storage errors. Until implemented,
        deletion recovery keeps staged logs and the intent marker for review.
        """
        raise NotImplementedError("authoritative job presence is not supported by this JobDefManager")

    @abstractmethod
    def create(self, meta: dict, uploaded_content: str | bytes, fl_ctx: FLContext) -> dict[str, Any]:
        """Create a new job permanently.

        The caller must have validated the content already and created initial meta. Receives bytes of uploaded folder,
        uploading to permanent store, create unique Job ID (jid) and return meta.

        Args:
            meta: caller-provided meta info
            uploaded_content: data of the job definition: data bytes or file name that contains the data bytes
            fl_ctx (FLContext): FLContext information

        Returns:
            A dict containing meta info. Additional meta info are added, especially
            a unique Job ID (jid) which has been created.
        """
        pass

    def get_job_content_hash(self, uploaded_content: str | bytes) -> str:
        """Compute the canonical content hash for uploaded job content.

        The hash is based on sorted real job file paths and bytes, excluding volatile
        submit signing artifacts. It is stable across repeated signed uploads of the
        same job content.
        """
        raise NotImplementedError("job content hashing is not supported by this JobDefManager")

    def get_submit_record(self, study: str, submitter, submit_token: str, fl_ctx: FLContext) -> dict | None:
        """Get the persistent submit-token record for the scoped submit token."""
        raise NotImplementedError("submit-token records are not supported by this JobDefManager")

    @staticmethod
    def new_submit_record(
        study: str,
        submitter,
        submit_token: str,
        job_content_hash: str,
        job_name: str = "",
        job_folder_name: str = "",
        job_id: str = None,
        state: str = SubmitRecordState.CREATING.value,
    ) -> dict:
        """Build a submit-token record with a pre-generated job_id for reservation before job creation."""
        raise NotImplementedError("submit-token records are not supported by this JobDefManager")

    def create_submit_record(self, record: dict, fl_ctx: FLContext) -> bool:
        """Create a persistent submit-token record with no-overwrite semantics.

        Returns True when the record is created, False when a record already exists
        for the same study, submitter, and submit token.
        """
        raise NotImplementedError("submit-token records are not supported by this JobDefManager")

    def update_submit_record(self, record: dict, fl_ctx: FLContext) -> dict:
        """Replace the persistent submit-token record with updated metadata."""
        raise NotImplementedError("submit-token records are not supported by this JobDefManager")

    def mark_submit_records_job_deleted(self, job_id: str, deleted_by, fl_ctx: FLContext) -> list[dict]:
        """Mark submit-token records that reference a deleted job.

        Custom job managers that do not maintain submit-token records can keep the
        default no-op behavior for compatibility.
        """
        return []

    def get_job_by_submit_token(self, study: str, submitter, submit_token: str, fl_ctx: FLContext) -> Job | None:
        """Resolve a submit-token record to its referenced Job, if both exist."""
        raise NotImplementedError("submit-token records are not supported by this JobDefManager")

    @abstractmethod
    def clone(self, from_jid: str, meta: dict, fl_ctx: FLContext) -> dict[str, Any]:
        """Create a new job by cloning an existing job.

        Args:
            from_jid: the job to be cloned
            meta: meta info for the new job
            fl_ctx: FLContext info

        Returns:
            A dict containing meta info. Additional meta info are added, especially
            a unique Job ID (jid) which has been created.

        """
        pass

    @abstractmethod
    def get_job(self, jid: str, fl_ctx: FLContext) -> Job:
        """Gets the Job object through the job ID.

        Args:
            jid (str): Job ID
            fl_ctx (FLContext): FLContext information

        Returns:
            A Job object
        """
        pass

    @abstractmethod
    def get_app(self, job: Job, app_name: str, fl_ctx: FLContext) -> bytes:
        """Get the contents of the specified app in bytes.

        Args:
            job: Job object
            app_name: name of the app to get
            fl_ctx (FLContext): FLContext information

        Returns:
            Content of the specified app in bytes
        """
        pass

    @abstractmethod
    def get_content(self, meta: dict, fl_ctx: FLContext) -> bytes | None:
        """Gets the entire uploaded content for a Job.

        Args:
            meta (dict): the meta info of the job
            fl_ctx (FLContext): FLContext information

        Returns:
            Uploaded content of the job in bytes
        """
        pass

    @abstractmethod
    def update_meta(self, jid: str, meta, fl_ctx: FLContext):
        """Update the meta of an existing Job.

        Args:
            jid (str): Job ID
            meta: dictionary of metadata for the job
            fl_ctx (FLContext): FLContext information

        """
        pass

    @abstractmethod
    def refresh_meta(self, job: Job, meta_keys: list, fl_ctx: FLContext):
        """Refresh meta of the job as specified in the meta keys
        Save the values of the specified keys into job store

        Args:
            job: job object
            meta_keys: meta keys need to updated
            fl_ctx: FLContext

        """
        pass

    @abstractmethod
    def set_client_data(self, jid: str, data: bytes | str, client_name: str, data_type: str, fl_ctx: FLContext):
        """Save the provided data content for the specified job, client name and data type.

        Args:
            jid (str): Job ID
            data: data content, either as bytes or a string representing the file name that contains the data
            client_name (str): client name
            data_type (str): data type
            fl_ctx (FLContext): FLContext information

        """
        pass

    @abstractmethod
    def get_client_data(self, jid: str, client_name: str, data_type: str, fl_ctx: FLContext) -> bytes | None:
        """Get data content for the specified job, client name and data type.

        Args:
            jid (str): Job ID
            client_name (str): client name
            data_type (str): data type
            fl_ctx (FLContext): FLContext information

        Returns:
            data content

        """
        pass

    @abstractmethod
    def list_components(self, jid: str, fl_ctx: FLContext) -> list[str]:
        """Get list of all the components for the specified job.

        Args:
            jid (str): Job ID
            fl_ctx (FLContext): FLContext information

        Returns:
            list of components

        """
        pass

    @abstractmethod
    def set_status(self, jid: str, status: RunStatus, fl_ctx: FLContext):
        """Set status of an existing Job.

        Args:
            jid (str): Job ID
            status (RunStatus): status to set
            fl_ctx (FLContext): FLContext information

        """
        pass

    @abstractmethod
    def get_jobs_to_schedule(self, fl_ctx: FLContext) -> list[Job]:
        """Get job candidates for scheduling.

        Args:
            fl_ctx: FL context

        Returns: list of jobs for scheduling

        """
        pass

    @abstractmethod
    def get_all_jobs(self, fl_ctx: FLContext) -> list[Job]:
        """Gets all Jobs in the system.

        Args:
            fl_ctx (FLContext): FLContext information

        Returns:
            A list of all jobs
        """
        pass

    @abstractmethod
    def get_jobs_by_status(self, run_status: RunStatus | list[RunStatus], fl_ctx: FLContext) -> list[Job]:
        """Gets Jobs of a specified status.

        Args:
            run_status: status to filter for: a single or a list of status values
            fl_ctx (FLContext): FLContext information

        Returns:
            A list of Jobs of the specified status
        """
        pass

    @abstractmethod
    def get_jobs_waiting_for_review(self, reviewer_name: str, fl_ctx: FLContext) -> list[Job]:
        """Gets Jobs waiting for review for the specified user.

        Args:
            reviewer_name (str): reviewer name
            fl_ctx (FLContext): FLContext information

        Returns:
            A list of Jobs waiting for review for the specified user.
        """
        pass

    @abstractmethod
    def set_approval(
        self, jid: str, reviewer_name: str, approved: bool, note: str, fl_ctx: FLContext
    ) -> dict[str, Any]:
        """Sets the approval for the specified user for a certain Job.

        Args:
            jid (str): job id
            reviewer_name (str): reviewer name
            approved (bool): whether job is approved
            note (str): any note message
            fl_ctx (FLContext): FLContext information

        Returns:
            A dictionary of Job metadata.
        """
        pass

    @abstractmethod
    def delete(self, jid: str, fl_ctx: FLContext):
        """Deletes the specified Job.

        Args:
            jid (str): Job ID
            fl_ctx (FLContext): FLContext information

        """
        pass

    def save_job_outputs(self, jid: str, data: list[str], fl_ctx: FLContext) -> str | None:
        """Save the job's outputs to the job storage, as their own archive.

        The outputs are the files the job produced. The server names them in folders of hard links, which this
        method archives; the rest of the workspace is then saved with ``save_workspace`` without them, so each file
        is stored once. The folders hold links to the job's files: an implementation reads them and must not move or
        delete their contents. A full download sends both archives; an outputs-only download sends this one.
        Optional: an implementation that does not save it returns None, and the server then keeps the files in the
        workspace archive.

        Args:
            jid (str): Job ID
            data: folders whose files make up the archive, each at its path relative to the folder
            fl_ctx (FLContext): FLContext information

        Returns: location where the archive is saved at, or None when it is not saved
        """
        return None

    @abstractmethod
    def save_workspace(self, jid: str, data: bytes | str | list[str], fl_ctx: FLContext) -> str:
        """Save the job workspace to the job storage.

        Args:
            jid (str): Job ID
            data: Job workspace data; or name of data file; or list of file/dir names
            fl_ctx (FLContext): FLContext information

        Returns: location where the workspace is saved at

        """
        pass

    @abstractmethod
    def get_storage_component(self, jid: str, component: str, fl_ctx: FLContext):
        """Get the workspace data from the job storage.

        Args:
            jid (str): Job ID
            component: storage component name
            fl_ctx (FLContext): FLContext information

        """
        pass

    @abstractmethod
    def get_storage_for_download(
        self, jid: str, download_dir: str, component: str, download_file: str, fl_ctx: FLContext
    ):
        """Get the workspace data from the job storage.

        Args:
            jid (str): Job ID
            download_dir: download folder
            component: storage component name
            download_file: download file name
            fl_ctx (FLContext): FLContext information

        """
        pass
