# Copyright (c) 2022, NVIDIA CORPORATION.  All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import os
from typing import Union

from nvflare.app_common.resource_managers.auto_clean_resource_manager import AutoCleanResourceManager
from nvflare.fuel.utils.gpu_utils import (
    CUDA_VISIBLE_DEVICES,
    get_host_gpu_ids,
    get_host_gpu_memory_total,
    get_visible_gpu_ids,
)


class GPUResource:
    def __init__(self, gpu_id: int, gpu_memory: Union[int, float]):
        self.id = gpu_id
        self.memory = gpu_memory

    def to_dict(self):
        return {"gpu_id": self.id, "memory": self.memory}


class GPUResourceManager(AutoCleanResourceManager):
    def __init__(
        self,
        num_of_gpus: int,
        mem_per_gpu_in_GiB: Union[int, float],
        num_gpu_key: str = "num_of_gpus",
        gpu_mem_key: str = "mem_per_gpu_in_GiB",
        expiration_period: Union[int, float] = 30,
        ignore_host: bool = False,
        exclusive: bool = False,
    ):
        """Resource manager for GPUs.

        Args:
            num_of_gpus: Number of GPUs.
            mem_per_gpu_in_GiB: Memory for each GPU.
            num_gpu_key: The key in resource requirements that specify the number of GPUs.
            gpu_mem_key: The key in resource requirements that specify the memory per GPU.
            expiration_period: Number of seconds to hold the resources reserved.
                If check_resources is called but after "expiration_period" no allocate resource is called,
                then the reserved resources will be released.
            ignore_host: Whether to skip validation against GPUs present on the local host. Set to True in
                environments where the NVFlare process runs on a node without GPUs (for example, some
                Kubernetes deployments) but GPU resources are managed externally.
            exclusive: Reserve the full configured memory budget per device, so jobs cannot share a GPU.
                With ignore_host=True, a nonempty CUDA_VISIBLE_DEVICES mask selects the pool's integer GPU IDs.
        """
        if not isinstance(num_of_gpus, int):
            raise ValueError(f"num_of_gpus should be of type int, but got {type(num_of_gpus)}.")
        if num_of_gpus < 0:
            raise ValueError("num_of_gpus should be greater than or equal to 0.")

        if not isinstance(mem_per_gpu_in_GiB, (float, int)):
            raise ValueError(f"mem_per_gpu_in_GiB should be of type int or float, but got {type(mem_per_gpu_in_GiB)}.")
        if mem_per_gpu_in_GiB < 0:
            raise ValueError("mem_per_gpu_in_GiB should be greater than or equal to 0.")

        if not isinstance(expiration_period, (float, int)):
            raise ValueError(f"expiration_period should be of type int or float, but got {type(expiration_period)}.")
        if expiration_period < 0:
            raise ValueError("expiration_period should be greater than or equal to 0.")

        if not isinstance(ignore_host, bool):
            raise ValueError(f"ignore_host should be of type bool, but got {type(ignore_host)}.")
        if not isinstance(exclusive, bool):
            raise ValueError("exclusive must be a bool")
        self.exclusive = exclusive
        self.mem_per_gpu_in_GiB = mem_per_gpu_in_GiB

        resource_gpu_ids = list(range(num_of_gpus))
        if ignore_host and exclusive and num_of_gpus and os.environ.get(CUDA_VISIBLE_DEVICES, "").strip():
            visible_gpu_ids = get_visible_gpu_ids()
            if visible_gpu_ids is None:
                raise ValueError("CUDA_VISIBLE_DEVICES must contain integer GPU indices for an exclusive pool")
            if num_of_gpus > len(visible_gpu_ids):
                raise ValueError("num_of_gpus exceeds the CUDA_VISIBLE_DEVICES pool")
            resource_gpu_ids = visible_gpu_ids[:num_of_gpus]
        elif not ignore_host:
            if num_of_gpus > 0:
                host_gpu_ids = get_host_gpu_ids()
                managed_host_gpu_ids = get_visible_gpu_ids(host_gpu_ids)
                if managed_host_gpu_ids is None:
                    managed_host_gpu_ids = host_gpu_ids
                num_host_gpus = len(managed_host_gpu_ids)
                if num_of_gpus > num_host_gpus:
                    raise ValueError(f"num_of_gpus specified ({num_of_gpus}) exceeds available GPUs: {num_host_gpus}.")

                host_gpu_mem = get_host_gpu_memory_total()
                host_gpu_mem_by_id = {
                    gpu_id: host_gpu_mem[index]
                    for index, gpu_id in enumerate(host_gpu_ids)
                    if index < len(host_gpu_mem)
                }
                resource_gpu_ids = managed_host_gpu_ids[:num_of_gpus]
                for gpu_id in resource_gpu_ids:
                    try:
                        available_gpu_mem = host_gpu_mem_by_id[gpu_id]
                    except KeyError as e:
                        raise RuntimeError(f"Failed to determine GPU memory for GPU ID {gpu_id}.") from e
                    if mem_per_gpu_in_GiB * 1024 > available_gpu_mem:
                        raise ValueError(
                            f"Memory per GPU specified ({mem_per_gpu_in_GiB * 1024}) exceeds available GPU memory "
                            f"for GPU ID {gpu_id}: {available_gpu_mem}."
                        )

        self.num_gpu_key = num_gpu_key
        self.gpu_mem_key = gpu_mem_key
        gpu_memory = (mem_per_gpu_in_GiB or 1) if exclusive else mem_per_gpu_in_GiB
        resources = {i: GPUResource(gpu_id=i, gpu_memory=gpu_memory) for i in resource_gpu_ids}

        super().__init__(resources=resources, expiration_period=expiration_period)

    def _deallocate(self, resources: dict):
        for k, v in resources.items():
            self.resources[k].memory += v

    def _check_required_resource_available(self, resource_requirement: dict) -> bool:
        if not resource_requirement:
            return True

        if self.num_gpu_key not in resource_requirement:
            raise ValueError(f"resource_requirement is missing num_gpu_key {self.num_gpu_key}.")

        num_gpu = resource_requirement[self.num_gpu_key]
        if num_gpu == 0:
            return True
        gpu_mem = resource_requirement.get(self.gpu_mem_key, 0)
        if self.exclusive:
            if self.mem_per_gpu_in_GiB and gpu_mem > self.mem_per_gpu_in_GiB:
                return False
            gpu_mem = self.mem_per_gpu_in_GiB or 1

        satisfied = 0
        for r in self.resources.values():
            if r.memory >= gpu_mem:
                satisfied += 1
            if satisfied >= num_gpu:
                return True
        return False

    def _reserve_resource(self, resource_requirement: dict) -> dict:
        if not resource_requirement:
            return {}

        if self.num_gpu_key not in resource_requirement:
            raise ValueError(f"resource_requirement is missing num_gpu_key {self.num_gpu_key}.")

        reserved_resources = {}
        num_gpu = resource_requirement[self.num_gpu_key]
        gpu_mem = (self.mem_per_gpu_in_GiB or 1) if self.exclusive else resource_requirement.get(self.gpu_mem_key, 0)
        if num_gpu == 0:
            return reserved_resources

        for k, r in self.resources.items():
            if r.memory >= gpu_mem:
                r.memory -= gpu_mem
                reserved_resources[k] = gpu_mem
            if len(reserved_resources) == num_gpu:
                break
        return reserved_resources

    def _resource_to_dict(self) -> dict:
        return {
            "resources": [self.resources[k].to_dict() for k in self.resources],
            "reserved_resources": self.reserved_resources,
        }
