# Copyright (c) 2026, NVIDIA CORPORATION.  All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Default component policy for non-BYOC jobs.

Installed in provisioned and simulation workspaces. ``ComponentPathAuthorizer``
also uses it as the built-in default when a site does not configure
``class_allow_list``, recording an audit event for the implicit policy decision.
"""

DEFAULT_CLASS_ALLOW_LIST = (
    "nvflare.app_common.aggregators.collect_and_assemble_aggregator.CollectAndAssembleAggregator",
    "nvflare.app_common.aggregators.collect_and_assemble_model_aggregator.CollectAndAssembleModelAggregator",
    "nvflare.app_common.aggregators.intime_accumulate_model_aggregator.InTimeAccumulateWeightedAggregator",
    "nvflare.app_common.ccwf.CrossSiteEvalClientController",
    "nvflare.app_common.ccwf.CrossSiteEvalServerController",
    "nvflare.app_common.ccwf.CyclicClientController",
    "nvflare.app_common.ccwf.CyclicServerController",
    "nvflare.app_common.ccwf.SwarmClientController",
    "nvflare.app_common.ccwf.SwarmServerController",
    "nvflare.app_common.ccwf.client_controller_executor.ClientControllerExecutor",
    "nvflare.app_common.ccwf.comps.cwe_result_printer.CWEResultPrinter",
    "nvflare.app_common.ccwf.comps.np_file_model_persistor.NPFileModelPersistor",
    "nvflare.app_common.ccwf.comps.np_trainer.NPTrainer",
    "nvflare.app_common.ccwf.comps.simple_intime_model_selector.SimpleIntimeModelSelector",
    "nvflare.app_common.ccwf.comps.simple_model_shareable_generator.SimpleModelShareableGenerator",
    "nvflare.app_common.ccwf.cse_client_ctl.CrossSiteEvalClientController",
    "nvflare.app_common.ccwf.cse_server_ctl.CrossSiteEvalServerController",
    "nvflare.app_common.ccwf.cyclic_client_ctl.CyclicClientController",
    "nvflare.app_common.ccwf.cyclic_server_ctl.CyclicServerController",
    "nvflare.app_common.ccwf.server_ctl.ServerSideController",
    "nvflare.app_common.ccwf.swarm_client_ctl.SwarmClientController",
    "nvflare.app_common.ccwf.swarm_server_ctl.SwarmServerController",
    "nvflare.app_common.executors.model_learner_executor.ModelLearnerExecutor",
    "nvflare.app_common.executors.statistics.statistics_executor.StatisticsExecutor",
    "nvflare.app_common.filters.exclude_vars.ExcludeVars",
    "nvflare.app_common.filters.percentile_privacy.PercentilePrivacy",
    "nvflare.app_common.filters.statistics_privacy_filter.StatisticsPrivacyFilter",
    "nvflare.app_common.filters.svt_privacy.SVTPrivacy",
    "nvflare.app_common.logging.job_log_receiver.JobLogReceiver",
    "nvflare.app_common.logging.job_log_streamer.JobLogStreamer",
    "nvflare.app_common.np.np_formatter.NPFormatter",
    "nvflare.app_common.np.np_model_locator.NPModelLocator",
    "nvflare.app_common.np.np_model_persistor.NPModelPersistor",
    "nvflare.app_common.np.np_trainer.NPTrainer",
    "nvflare.app_common.np.np_validator.NPValidator",
    "nvflare.app_common.psi.dh_psi.dh_psi_controller.DhPSIController",
    "nvflare.app_common.psi.file_psi_writer.FilePSIWriter",
    "nvflare.app_common.psi.psi_executor.PSIExecutor",
    "nvflare.app_common.shareablegenerators.full_model_shareable_generator.FullModelShareableGenerator",
    "nvflare.app_common.statistics.histogram_bins_cleanser.HistogramBinsCleanser",
    "nvflare.app_common.statistics.json_stats_file_persistor.JsonStatsFileWriter",
    "nvflare.app_common.statistics.min_count_cleanser.MinCountCleanser",
    "nvflare.app_common.statistics.min_max_cleanser.AddNoiseToMinMax",
    "nvflare.app_common.utils.json_utils.ObjectEncoder",
    "nvflare.app_common.widgets.convert_to_fed_event.ConvertToFedEvent",
    "nvflare.app_common.widgets.event_recorder.ClientEventRecorder",
    "nvflare.app_common.widgets.event_recorder.ServerEventRecorder",
    "nvflare.app_common.widgets.intime_model_selector.IntimeModelSelector",
    "nvflare.app_common.widgets.metrics_artifact_writer.MetricsArtifactWriter",
    "nvflare.app_common.widgets.validation_json_generator.ValidationJsonGenerator",
    "nvflare.app_common.workflows.cross_site_model_eval.CrossSiteModelEval",
    "nvflare.app_common.workflows.cyclic_ctl.CyclicController",
    "nvflare.app_common.workflows.fedavg.FedAvg",
    "nvflare.app_common.workflows.global_model_eval.GlobalModelEval",
    "nvflare.app_common.workflows.initialize_global_weights.InitializeGlobalWeights",
    "nvflare.app_common.workflows.lr.fedavg.FedAvgLR",
    "nvflare.app_common.workflows.lr.np_persistor.LRModelPersistor",
    "nvflare.app_common.workflows.scaffold.Scaffold",
    "nvflare.app_common.workflows.scatter_and_gather.ScatterAndGather",
    "nvflare.app_common.workflows.statistics_controller.StatisticsController",
    "nvflare.app_opt.he.intime_accumulate_model_aggregator.HEInTimeAccumulateWeightedAggregator",
    "nvflare.app_opt.he.model_decryptor.HEModelDecryptor",
    "nvflare.app_opt.he.model_encryptor.HEModelEncryptor",
    "nvflare.app_opt.he.model_serialize_filter.HEModelSerializeFilter",
    "nvflare.app_opt.he.model_shareable_generator.HEModelShareableGenerator",
    "nvflare.app_opt.psi.dh_psi.dh_psi_task_handler.DhPSITaskHandler",
    "nvflare.app_opt.pt.fedopt.PTFedOptModelShareableGenerator",
    "nvflare.app_opt.pt.fedopt_ctl.FedOpt",
    "nvflare.app_opt.pt.file_model_locator.PTFileModelLocator",
    "nvflare.app_opt.pt.recipes.fedeval.EvalController",
    "nvflare.app_opt.sklearn.kmeans_assembler.KMeansAssembler",
    "nvflare.app_opt.sklearn.svm_assembler.SVMAssembler",
    "nvflare.app_opt.tf.fedopt_ctl.FedOpt",
    "nvflare.app_opt.tf.file_model_locator.TFFileModelLocator",
    "nvflare.app_opt.tracking.mlflow.mlflow_receiver.MLflowReceiver",
    "nvflare.app_opt.tracking.mlflow.mlflow_writer.MLflowWriter",
    "nvflare.app_opt.tracking.tb.tb_receiver.TBAnalyticsReceiver",
    "nvflare.app_opt.tracking.tb.tb_writer.TBWriter",
    "nvflare.app_opt.tracking.wandb.wandb_receiver.WandBReceiver",
    "nvflare.app_opt.xgboost.histogram_based.controller.XGBFedController",
    "nvflare.app_opt.xgboost.histogram_based.executor.FedXGBHistogramExecutor",
    "nvflare.app_opt.xgboost.histogram_based_v2.csv_data_loader.CSVDataLoader",
    "nvflare.app_opt.xgboost.histogram_based_v2.fed_controller.XGBFedController",
    "nvflare.app_opt.xgboost.histogram_based_v2.fed_executor.FedXGBHistogramExecutor",
    "nvflare.app_opt.xgboost.tree_based.bagging_aggregator.XGBBaggingAggregator",
    "nvflare.app_opt.xgboost.tree_based.executor.FedXGBTreeExecutor",
    "nvflare.app_opt.xgboost.tree_based.model_persistor.XGBModelPersistor",
    "nvflare.app_opt.xgboost.tree_based.shareable_generator.XGBModelShareableGenerator",
)
