# Copyright (c) 2023, NVIDIA CORPORATION.  All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import json
from typing import Optional, Tuple, Union

import torch
from safetensors.torch import load, save

import nvflare.fuel.utils.fobs.dots as dots
from nvflare.app_common.utils.tensor_disk_offload_context import (
    _TENSOR_DISK_OFFLOAD_CONTEXT,
    _TENSOR_DISK_OFFLOAD_ROOT_DIR,
    TensorDiskOffloadContext,
)
from nvflare.fuel.f3.streaming.download_service import Downloadable
from nvflare.fuel.utils.fobs import FOBSContextKey
from nvflare.fuel.utils.fobs.datum import DatumManager
from nvflare.fuel.utils.fobs.decomposers.via_downloader import ViaDownloaderDecomposer

from ...fuel.f3.cellnet.cell import Cell
from .lazy_tensor_dict import LazyTensorDict, _LazyRef
from .tensor_downloader import TensorDownloadable, download_tensors, download_tensors_to_disk


class SerializationModule(torch.nn.Module):
    def __init__(self, tensor):
        super().__init__()
        self.register_buffer("saved_tensor", tensor)


class TensorDecomposer(ViaDownloaderDecomposer):

    def __init__(self):
        ViaDownloaderDecomposer.__init__(self, 1024 * 1024 * 2, "tensor_")

    def supported_type(self):
        return torch.Tensor

    def supported_aliases(self):
        # Disk-backed lazy refs travel the wire as the tensors they stand for.
        return [_LazyRef]

    def get_download_dot(self) -> int:
        return dots.TENSOR_DOWNLOAD

    def to_downloadable(self, items: dict, max_chunk_size: int, fobs_ctx: dict) -> Downloadable:
        return TensorDownloadable(items, max_chunk_size)

    def _get_download_kwargs(self, fobs_ctx: dict) -> dict:
        return {"fobs_ctx": fobs_ctx}

    def download(
        self,
        from_fqcn: str,
        ref_id: str,
        per_request_timeout: float,
        cell: Cell,
        secure=False,
        optional=False,
        abort_signal=None,
        progress_cb=None,
        fobs_ctx: dict = None,
    ) -> Tuple[str, Union[dict, LazyTensorDict]]:
        cell_ctx = cell.get_fobs_context()
        default_use_disk = cell_ctx.get(FOBSContextKey.TENSOR_DISK_OFFLOAD, False)
        fobs_ctx = fobs_ctx or {}
        return self._download(
            from_fqcn=from_fqcn,
            ref_id=ref_id,
            per_request_timeout=per_request_timeout,
            cell=cell,
            use_disk=fobs_ctx.get(FOBSContextKey.TENSOR_DISK_OFFLOAD, default_use_disk),
            root_dir=fobs_ctx.get(
                _TENSOR_DISK_OFFLOAD_ROOT_DIR,
                cell_ctx.get(_TENSOR_DISK_OFFLOAD_ROOT_DIR),
            ),
            offload_context=fobs_ctx.get(_TENSOR_DISK_OFFLOAD_CONTEXT, cell_ctx.get(_TENSOR_DISK_OFFLOAD_CONTEXT)),
            secure=secure,
            optional=optional,
            abort_signal=abort_signal,
            progress_cb=progress_cb,
        )

    @staticmethod
    def _download(
        from_fqcn: str,
        ref_id: str,
        per_request_timeout: float,
        cell: Cell,
        use_disk: bool,
        root_dir: Optional[str] = None,
        secure=False,
        optional=False,
        abort_signal=None,
        progress_cb=None,
        offload_context: Optional[TensorDiskOffloadContext] = None,
    ) -> Tuple[str, Union[dict, LazyTensorDict]]:
        if use_disk:
            return download_tensors_to_disk(
                from_fqcn=from_fqcn,
                ref_id=ref_id,
                per_request_timeout=per_request_timeout,
                cell=cell,
                root_dir=root_dir,
                offload_context=offload_context,
                secure=secure,
                optional=optional,
                abort_signal=abort_signal,
                progress_cb=progress_cb,
            )
        return download_tensors(
            from_fqcn=from_fqcn,
            ref_id=ref_id,
            per_request_timeout=per_request_timeout,
            cell=cell,
            secure=secure,
            optional=optional,
            abort_signal=abort_signal,
            progress_cb=progress_cb,
        )

    def native_decompose(self, target: torch.Tensor, manager: DatumManager = None) -> bytes:
        sink = manager.fobs_ctx.get(FOBSContextKey.TENSOR_FILE_SINK) if manager else None
        if sink is not None:
            return json.dumps(sink.add(target)).encode("utf-8")
        if isinstance(target, _LazyRef):
            raise ValueError("disk-backed tensors require an active Cell and tensor streaming")
        # save the tensor to bytes using safetensors
        dummy = {"t": target}
        return save(dummy)

    def native_recompose(self, data: bytes, manager: DatumManager = None) -> torch.Tensor:
        source = manager.fobs_ctx.get(FOBSContextKey.TENSOR_FILE_SOURCE) if manager else None
        if source is not None:
            return source.get(json.loads(data))
        # load safetensors generated bytes
        dummy = load(data)
        if not isinstance(dummy, dict):
            raise ValueError(f"failed to load data: should be dict but got {type(dummy)}")
        return dummy.get("t")
