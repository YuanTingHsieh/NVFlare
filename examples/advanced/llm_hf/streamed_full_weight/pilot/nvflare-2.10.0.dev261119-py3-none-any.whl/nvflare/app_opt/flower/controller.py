# Copyright (c) 2024, NVIDIA CORPORATION.  All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from typing import Optional

from nvflare.apis.fl_context import FLContext
from nvflare.app_common.tie.controller import TieController
from nvflare.app_common.tie.defs import Constant as TieConstant
from nvflare.app_opt.flower.applet import FlowerServerApplet
from nvflare.app_opt.flower.http_transport import DEFAULT_MAX_MESSAGE_BYTES
from nvflare.app_opt.flower.process import validate_command_timeout
from nvflare.fuel.utils.validation_utils import check_positive_number

from .defs import Constant


class FlowerController(TieController):
    def __init__(
        self,
        num_rounds=1,
        database: str = "",
        superlink_ready_timeout: float = 10.0,
        superlink_grace_period: float = 2.0,
        superlink_min_query_interval=10.0,
        monitor_interval: float = 0.5,
        configure_task_name=TieConstant.CONFIG_TASK_NAME,
        configure_task_timeout=TieConstant.CONFIG_TASK_TIMEOUT,
        start_task_name=TieConstant.START_TASK_NAME,
        start_task_timeout=TieConstant.START_TASK_TIMEOUT,
        job_status_check_interval: float = TieConstant.JOB_STATUS_CHECK_INTERVAL,
        max_client_op_interval: float = TieConstant.MAX_CLIENT_OP_INTERVAL,
        progress_timeout: float = TieConstant.WORKFLOW_PROGRESS_TIMEOUT,
        run_config: Optional[dict] = None,
        max_message_bytes: int = DEFAULT_MAX_MESSAGE_BYTES,
        allow_runtime_dependency_installation: bool = False,
        flower_app_path: Optional[str] = None,
        flwr_run_timeout: float = Constant.FLWR_RUN_TIMEOUT,
        flwr_command_timeout: float = Constant.FLWR_COMMAND_TIMEOUT,
        flwr_log_timeout: float = Constant.FLWR_LOG_TIMEOUT,
    ):
        """Constructor of FlowerController

        Args:
            num_rounds: number of rounds. Not used in this version.
            database: database name
            superlink_ready_timeout: how long to wait for the superlink to become ready before starting server app
            superlink_min_query_interval: minimal interval for querying superlink for status
            monitor_interval: how often to check flower run status
            configure_task_name: name of the config task
            configure_task_timeout: max time allowed for config task to complete
            start_task_name: name of the start task
            start_task_timeout: max time allowed for start task to complete
            job_status_check_interval: how often to check job status
            max_client_op_interval: max time allowed for missing client requests
            progress_timeout: max time allowed for missing overall progress
            run_config: optional dict for flwr run --run-config arguments
            max_message_bytes: maximum HTTP request or response body size in bytes. Defaults to 512 MiB.
            allow_runtime_dependency_installation: whether to allow dynamic dependency installation
            flower_app_path: absolute path to pre-deployed Flower app on the server (clients receive via FAB)
            flwr_run_timeout: seconds allowed for CLI startup, FAB preparation and run submission. Defaults to 300.
            flwr_command_timeout: seconds allowed for each status or stop CLI command. Defaults to 15.
            flwr_log_timeout: seconds allowed for the best-effort log snapshot during shutdown. Defaults to 5.
        """
        TieController.__init__(
            self,
            configure_task_name=configure_task_name,
            configure_task_timeout=configure_task_timeout,
            start_task_name=start_task_name,
            start_task_timeout=start_task_timeout,
            job_status_check_interval=job_status_check_interval,
            max_client_op_interval=max_client_op_interval,
            progress_timeout=progress_timeout,
        )

        check_positive_number("superlink_ready_timeout", superlink_ready_timeout)
        check_positive_number("superlink_grace_period", superlink_grace_period)
        check_positive_number("monitor_interval", monitor_interval)
        check_positive_number("superlink_min_query_interval", superlink_min_query_interval)
        for name, value in (
            ("flwr_run_timeout", flwr_run_timeout),
            ("flwr_command_timeout", flwr_command_timeout),
            ("flwr_log_timeout", flwr_log_timeout),
        ):
            validate_command_timeout(name, value)

        self.num_rounds = num_rounds
        self.database = database
        self.superlink_ready_timeout = superlink_ready_timeout
        self.superlink_grace_period = superlink_grace_period
        self.superlink_min_query_interval = superlink_min_query_interval
        self.monitor_interval = monitor_interval
        self.run_config = run_config
        self.max_message_bytes = max_message_bytes
        self.allow_runtime_dependency_installation = allow_runtime_dependency_installation
        self.flower_app_path = flower_app_path
        self.flwr_run_timeout = flwr_run_timeout
        self.flwr_command_timeout = flwr_command_timeout
        self.flwr_log_timeout = flwr_log_timeout

    def get_connector(self, fl_ctx: FLContext):
        from nvflare.app_opt.flower.connectors.http_server_connector import HttpServerConnector

        return HttpServerConnector(
            max_message_bytes=self.max_message_bytes,
            monitor_interval=self.monitor_interval,
        )

    def get_applet(self, fl_ctx: FLContext):
        return FlowerServerApplet(
            database=self.database,
            superlink_ready_timeout=self.superlink_ready_timeout,
            superlink_grace_period=self.superlink_grace_period,
            superlink_min_query_interval=self.superlink_min_query_interval,
            run_config=self.run_config,
            allow_runtime_dependency_installation=self.allow_runtime_dependency_installation,
            flower_app_path=self.flower_app_path,
            flwr_run_timeout=self.flwr_run_timeout,
            flwr_command_timeout=self.flwr_command_timeout,
            flwr_log_timeout=self.flwr_log_timeout,
        )

    def _process_client_done(self, topic, request, fl_ctx):
        # Generic TIE tolerates nonzero app-client exits. For Flower, a failed
        # SuperNode or uncertain Fleet transaction must fail the enclosing job.
        exit_code = request.get(TieConstant.MSG_KEY_EXIT_CODE, 0)
        if exit_code:
            self._trigger_stop(fl_ctx, f"Flower client stopped with exit code {exit_code}")
        return super()._process_client_done(topic, request, fl_ctx)

    def get_client_config_params(self, fl_ctx: FLContext) -> dict:
        return {
            Constant.CONF_KEY_NUM_ROUNDS: self.num_rounds,
        }

    def get_connector_config_params(self, fl_ctx: FLContext) -> dict:
        return {
            Constant.CONF_KEY_NUM_ROUNDS: self.num_rounds,
        }
