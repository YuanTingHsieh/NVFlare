# Copyright (c) 2026, NVIDIA CORPORATION.  All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Public NVFlare integration surface for the Slurm job launcher."""

from __future__ import annotations

import copy
import math
import os
import secrets
import shlex
from abc import abstractmethod
from dataclasses import replace
from typing import Optional
from urllib.parse import urlsplit, urlunsplit

from nvflare.apis.event_type import EventType
from nvflare.apis.fl_constant import FLContextKey, JobConstants
from nvflare.apis.fl_context import FLContext
from nvflare.apis.job_def import JobMetaKey
from nvflare.apis.job_launcher_spec import (
    JobHandleSpec,
    JobLauncherSpec,
    JobProcessArgs,
    add_launcher,
    publish_job_handle,
)
from nvflare.apis.utils.format_check import check_job_id
from nvflare.apis.workspace import Workspace
from nvflare.app_opt.job_launcher.slurm.config import (
    _JOB_SLURM_KEYS,
    CONTAINER_RESOLV_CONF,
    JOB_SPEC_ADDITIONAL_NODE_COMMAND,
    SLURM_CHILD_PROCESS_ENV,
    BindMount,
    JobResources,
    LaunchPlan,
    SlurmConfig,
    SlurmLauncherError,
    _mapping_or_empty,
    _paths_overlap,
    _require_int,
    _require_positive_number,
    _require_string,
    _validate_mount_destination,
    _validate_mount_source,
    normalize_slurm_image,
    normalize_slurm_launcher_settings,
    normalize_slurm_workspace_path,
)
from nvflare.app_opt.job_launcher.slurm.manager import SlurmJobManager
from nvflare.app_opt.job_launcher.study_runtime import (
    StudyRuntime,
    load_study_runtime_file,
    reject_legacy_study_data,
    resolve_study_runtime,
    study_runtime_file_path,
)
from nvflare.client.cell.attach_rendezvous import ATTACH_COMM_CONFIG
from nvflare.fuel.f3.comm_error import CommError
from nvflare.fuel.f3.drivers.file_driver import ROOT_DIR as SHARED_FILE_ROOT_DIR
from nvflare.fuel.f3.drivers.file_driver import SCHEME as SHARED_FILE_SCHEME
from nvflare.fuel.f3.drivers.file_driver import parse_file_url
from nvflare.fuel.utils.config_service import ConfigService
from nvflare.fuel.utils.secret_utils import has_secret_refs
from nvflare.job_config.defs import ExecutionLifetime
from nvflare.job_config.task_execution import get_client_execution_lifetime
from nvflare.private.fed.client.task_runtime import JobHandleWithTaskWorkers
from nvflare.private.fed.utils.job_cert_utils import JobCertError, require_job_cert
from nvflare.utils.job_launcher_utils import (
    get_cj_resource_spec,
    get_client_job_args,
    get_credential_env,
    get_job_launcher_spec,
    get_portable_resource_spec,
    get_server_job_args,
    portable_memory_to_mib,
    validate_cj_execution_lifetime,
)


def _validate_child_dir(parent_real: str, path: str, what: str, parent_desc: str) -> str:
    if os.path.islink(path) or not os.path.isdir(path):
        raise SlurmLauncherError(f"{what} must be an existing non-symlink directory: {path}")
    real = os.path.realpath(path)
    if os.path.dirname(real) != parent_real:
        raise SlurmLauncherError(f"{what} must be an immediate child of {parent_desc}: {path}")
    return real


def _validate_run_dir(workspace_path: str, run_dir: str) -> str:
    return _validate_child_dir(os.path.realpath(workspace_path), run_dir, "job run directory", "workspace_path")


def _resolve_resources(
    job_meta: dict,
    site_name: str,
    sandbox: str,
    site_pending_timeout: float,
    spec: dict,
    *,
    allow_zero_gpus=False,
) -> JobResources:
    spec = _mapping_or_empty(spec, f"Slurm spec for site '{site_name}'")
    unknown = set(spec) - _JOB_SLURM_KEYS
    if unknown:
        raise SlurmLauncherError(f"unsupported job-owned Slurm key(s): {sorted(unknown)}")

    nodes = _require_int(spec.get("nodes", 1), "nodes")
    if nodes > 1 and sandbox != "none" and spec.get(JOB_SPEC_ADDITIONAL_NODE_COMMAND) is None:
        raise SlurmLauncherError(
            "multi-node Slurm jobs require effective sandbox 'none' unless additional_node_command requests "
            "launcher-owned fan-out"
        )

    def optional_int(name: str) -> Optional[int]:
        value = spec.get(name)
        return None if value is None else _require_int(value, name)

    raw_gpus = spec.get("gpus_per_node")
    gpus_per_node = None if raw_gpus is None else _require_int(raw_gpus, "gpus_per_node", 0 if allow_zero_gpus else 1)
    portable = get_portable_resource_spec(job_meta, site_name)
    portable_total = portable.get("num_of_gpus")
    if portable_total is not None:
        portable_total = _require_int(portable_total, "num_of_gpus", 0)
    if gpus_per_node is not None and portable_total is not None and portable_total != nodes * gpus_per_node:
        raise SlurmLauncherError("num_of_gpus must equal nodes * gpus_per_node when both are specified")
    if nodes > 1 and portable_total and gpus_per_node is None:
        raise SlurmLauncherError("multi-node GPU jobs require explicit gpus_per_node")
    if gpus_per_node is None and portable_total is not None and (portable_total or allow_zero_gpus):
        gpus_per_node = portable_total

    cpus_per_node = optional_int("cpus_per_node")
    mem_per_node = optional_int("mem_per_node")
    if "num_of_cpus" in portable:
        cpus_per_node = portable["num_of_cpus"]
    if "memory" in portable:
        mem_per_node = portable_memory_to_mib(portable["memory"])
    time_limit = spec.get("time")
    if time_limit is not None:
        time_limit = _require_string(time_limit, "time")
    pending_timeout = _require_positive_number(spec.get("pending_timeout", site_pending_timeout), "pending_timeout")
    if pending_timeout > site_pending_timeout:
        raise SlurmLauncherError("job pending_timeout may only reduce the site value")
    return JobResources(
        nodes=nodes,
        gpus_per_node=gpus_per_node,
        cpus_per_node=cpus_per_node,
        mem_per_node=mem_per_node,
        time_limit=time_limit,
        pending_timeout=pending_timeout,
    )


def _resolve_additional_node_command(
    job_spec: dict, nodes: int, workspace: Workspace, job_id: str, run_dir: str, supported: bool
) -> tuple[tuple, Optional[str]]:
    raw = job_spec.get(JOB_SPEC_ADDITIONAL_NODE_COMMAND)
    if raw is None:
        return (), None
    if not supported:
        raise SlurmLauncherError("additional_node_command is only supported for client jobs")
    raw = _require_string(raw, JOB_SPEC_ADDITIONAL_NODE_COMMAND)
    if "\n" in raw or "\r" in raw:
        raise SlurmLauncherError("additional_node_command must be a single line")
    if has_secret_refs(raw):
        raise SlurmLauncherError("additional_node_command does not support secret references")
    if nodes < 2:
        raise SlurmLauncherError("additional_node_command requires nodes > 1")
    try:
        tokens = shlex.split(raw, posix=True)
    except ValueError as e:
        raise SlurmLauncherError("malformed additional_node_command") from e
    if not tokens:
        raise SlurmLauncherError("additional_node_command must contain at least one word")
    app_real = _validate_child_dir(run_dir, workspace.get_app_dir(job_id), "job app directory", "the run dir")
    return tuple(tokens), app_real


def _module_args(job_args: dict, arg_names: list[str]) -> tuple:
    result = []
    for name in arg_names:
        entry = job_args.get(name)
        if not entry:
            continue
        flag, value = entry
        result.append(str(flag))
        if name == JobProcessArgs.OPTIONS:
            if not isinstance(value, str):
                raise SlurmLauncherError("JOB_PROCESS_ARGS options must be a string")
            try:
                result.extend(shlex.split(value))
            except ValueError as e:
                raise SlurmLauncherError("malformed JOB_PROCESS_ARGS options") from e
        else:
            result.append(str(value))
    return tuple(result)


def _resolve_parent_host(configured_host: Optional[str]) -> str:
    if configured_host is not None:
        return _require_string(configured_host, "parent_host")
    if "SLURM_JOB_ID" in os.environ:
        return _require_string(os.environ.get("SLURMD_NODENAME"), "SLURMD_NODENAME")
    raise SlurmLauncherError("parent_host is required when the CP does not run inside a Slurm allocation")


def _rewrite_parent_url(job_args: dict, parent_host: Optional[str], internal_port: int) -> dict:
    copied = dict(job_args)
    entry = copied.get(JobProcessArgs.PARENT_URL)
    if not isinstance(entry, (tuple, list)) or len(entry) != 2:
        raise SlurmLauncherError(f"missing or malformed {JobProcessArgs.PARENT_URL} in JOB_PROCESS_ARGS")
    flag, raw_url = entry
    try:
        parsed = urlsplit(str(raw_url))
    except ValueError as e:
        raise SlurmLauncherError("malformed parent URL in JOB_PROCESS_ARGS") from e

    if parsed.scheme == SHARED_FILE_SCHEME:
        # Shared-file transport: the directory path is location-independent, so the URL
        # (including its tuning query parameters) is preserved without any host/port rewrite
        try:
            parse_file_url(str(raw_url))
        except CommError as e:
            raise SlurmLauncherError(f"malformed shared-file parent URL in JOB_PROCESS_ARGS: {raw_url!r}") from e
        return copied

    try:
        port = parsed.port
        host = parsed.hostname
    except ValueError as e:
        raise SlurmLauncherError("malformed parent URL in JOB_PROCESS_ARGS") from e
    if parsed.scheme not in ("tcp", "stcp") or port != internal_port or not host:
        raise SlurmLauncherError(
            f"parent URL must use {SHARED_FILE_SCHEME}, tcp, or stcp with configured internal_port "
            f"{internal_port}, got {raw_url!r}"
        )
    host = _resolve_parent_host(parent_host)
    rendered_host = host if host.startswith("[") and host.endswith("]") else f"[{host}]" if ":" in host else host
    netloc = f"{rendered_host}:{internal_port}"
    rewritten = urlunsplit((parsed.scheme, netloc, parsed.path, parsed.query, parsed.fragment))
    copied[JobProcessArgs.PARENT_URL] = (flag, rewritten)
    return copied


def _file_parent_mount(parent_url: str, workspace_path: str) -> Optional[BindMount]:
    """Bind mount for a shared-file transport parent URL so the CJ container can reach the
    transport parent at the same absolute path as the CP."""
    if urlsplit(str(parent_url)).scheme != SHARED_FILE_SCHEME:
        return None
    listen_dir = parse_file_url(str(parent_url))
    transport_parent = os.path.dirname(listen_dir)
    destination = _validate_mount_destination(transport_parent, "shared-file transport parent")
    source = _validate_mount_source(transport_parent, workspace_path, "shared-file transport parent")
    return BindMount(source, destination, "rw")


def _file_attach_mount(workspace: Workspace, workspace_path: str) -> Optional[BindMount]:
    """Bind mount for a site-configured shared-file Client API Attach root."""
    try:
        comm_config = ConfigService.load_config_dict(
            "comm_config.json", [workspace.get_site_config_dir()], raise_exception=False
        )
    except Exception as e:
        raise SlurmLauncherError("cannot load site-local comm_config.json for Client API Attach") from e
    if not isinstance(comm_config, dict):
        return None
    attach_config = comm_config.get(ATTACH_COMM_CONFIG)
    if not isinstance(attach_config, dict) or attach_config.get("scheme") != SHARED_FILE_SCHEME:
        return None
    resources = _mapping_or_empty(attach_config.get("resources"), f"{ATTACH_COMM_CONFIG}.resources in comm_config.json")
    root_dir = _require_string(
        resources.get(SHARED_FILE_ROOT_DIR), f"{ATTACH_COMM_CONFIG}.resources.{SHARED_FILE_ROOT_DIR}"
    )
    if ".." in root_dir.split("/"):
        _validate_mount_destination(root_dir, "shared-file Client API Attach root")
    destination = _validate_mount_destination(os.path.normpath(root_dir), "shared-file Client API Attach root")
    if os.path.islink(destination) or not os.path.isdir(destination):
        raise SlurmLauncherError(
            f"shared-file Client API Attach root must be an existing non-symlink directory: {destination}"
        )
    source = _validate_mount_source(destination, workspace_path, "shared-file Client API Attach root")
    return BindMount(source, destination, "rw")


def load_slurm_study_runtime(config, study, logger):
    runtime_file = study_runtime_file_path(config.workspace_path)
    try:
        reject_legacy_study_data(config.workspace_path)
    except RuntimeError as e:
        raise SlurmLauncherError(str(e)) from None
    if not os.path.exists(runtime_file):
        return StudyRuntime(study=study or "")
    try:
        runtime_map = load_study_runtime_file(runtime_file, launcher_mode="slurm", logger=logger)
        return resolve_study_runtime(runtime_map, study, runtime_file, logger=logger)
    except ValueError as e:
        raise SlurmLauncherError(str(e)) from e


def effective_slurm_study_values(config, runtime, job_image=None):
    slurm = runtime.slurm
    sandbox = slurm.get("sandbox", config.sandbox)
    if job_image is not None:
        job_image = _require_string(job_image, "job-owned Slurm image")
    if sandbox == "none" and (job_image or runtime.container_image or runtime.datasets or runtime.secret_mounts):
        raise SlurmLauncherError(
            "effective sandbox 'none' does not support job/study container, datasets, or secret_mounts"
        )
    image = (
        None
        if sandbox == "none"
        else normalize_slurm_image(
            job_image or runtime.container_image or config.image,
            sandbox,
            require_file=True,
            label="effective image",
        )
    )
    python_path = slurm.get("python_path", config.python_path)
    setup = slurm.get("setup", config.setup)
    directives = dict(config.sbatch_directives)
    directives.update({key: slurm[key] for key in ("partition", "account", "qos") if key in slurm})
    return sandbox, image, python_path, setup, directives


class SlurmJobLauncher(JobLauncherSpec):
    """Common lifecycle and launch-plan construction for client and server jobs."""

    EXE_MODULE: Optional[str] = None
    SUPPORTS_ADDITIONAL_NODE_COMMAND = False
    SUPPORTS_CLIENT_API_ATTACH = False

    def __init__(
        self,
        *,
        workspace_path: str,
        sandbox: str,
        python_path: str,
        executables: dict,
        image: Optional[str] = None,
        internal_port: int = 8102,
        sbatch_directives: Optional[dict] = None,
        setup: str = "",
        forward_env: Optional[list] = None,
        parent_host: Optional[str] = None,
        submit_timeout: float = 30.0,
        query_timeout: float = 10.0,
        cancel_timeout: float = 10.0,
        poll_interval: float = 10.0,
        pending_timeout: float = 600.0,
        multi_node_port_range=None,
    ):
        super().__init__()
        if not self.EXE_MODULE:
            raise TypeError("SlurmJobLauncher must be instantiated through a concrete subclass")
        self._child_process = os.environ.get(SLURM_CHILD_PROCESS_ENV) == "1"
        self.config = SlurmConfig(
            workspace_path=normalize_slurm_workspace_path(workspace_path),
            **normalize_slurm_launcher_settings(
                sandbox=sandbox,
                python_path=python_path,
                executables=executables,
                image=image,
                internal_port=internal_port,
                sbatch_directives=sbatch_directives,
                setup=setup,
                forward_env=forward_env,
                parent_host=parent_host,
                submit_timeout=submit_timeout,
                query_timeout=query_timeout,
                cancel_timeout=cancel_timeout,
                poll_interval=poll_interval,
                pending_timeout=pending_timeout,
                multi_node_port_range=multi_node_port_range,
            ),
        )
        self.manager = None
        if not self._child_process:
            self.manager = SlurmJobManager(
                config=self.config,
                logger=self.logger,
            )

    @abstractmethod
    def get_module_args(self, job_args: dict) -> tuple:
        """Select and structure the worker arguments for this launcher type."""

    def _load_study_runtime(self, study: Optional[str]) -> StudyRuntime:
        return load_slurm_study_runtime(self.config, study, self.logger)

    def _effective_study_values(self, runtime: StudyRuntime, job_image: Optional[str] = None):
        return effective_slurm_study_values(self.config, runtime, job_image)

    def _study_environment(self, runtime: StudyRuntime) -> tuple[dict, dict]:
        environment = dict(runtime.env)
        secret_environment = {}
        for reference in runtime.secret_env:
            if reference.source not in os.environ:
                raise SlurmLauncherError(
                    f"study secret_env '{reference.name}' requires parent environment variable '{reference.source}'"
                )
            secret_environment[reference.name] = _require_string(
                os.environ[reference.source],
                f"study secret_env '{reference.name}' value",
                allow_empty=True,
            )
        duplicated = (set(environment) | set(secret_environment)) & set(self.config.forward_env)
        if duplicated:
            raise SlurmLauncherError(
                f"study env, secret_env, and forward_env contain duplicate name(s): {sorted(duplicated)}"
            )
        return environment, secret_environment

    def _study_mounts(self, runtime: StudyRuntime) -> tuple:
        workspace = self.config.workspace_path
        owned_destinations = (workspace, CONTAINER_RESOLV_CONF)
        mounts = []
        specs = [
            (dataset, f"dataset '{dataset.dataset}'", "ro" if dataset.read_only else "rw")
            for dataset in runtime.datasets
        ] + [(secret, f"secret mount '{secret.name}'", "ro") for secret in runtime.secret_mounts]
        for item, label, mode in specs:
            destination = _validate_mount_destination(item.mount_path, f"{label} destination")
            owned_overlap = any(_paths_overlap(destination, owned) for owned in owned_destinations)
            other_overlap = any(_paths_overlap(destination, mount.destination) for mount in mounts)
            if owned_overlap or other_overlap:
                target = "a launcher-owned path" if owned_overlap else "another study mount"
                raise SlurmLauncherError(f"{label} destination overlaps {target}: {destination}")
            source = _validate_mount_source(
                item.source,
                workspace,
                f"{label} source",
            )
            mounts.append(BindMount(source, destination, mode))
        return tuple(mounts)

    @staticmethod
    def _python_environment(workspace: Workspace, job_id: str) -> str:
        custom_paths = (workspace.get_app_custom_dir(job_id), workspace.get_site_custom_dir())
        return os.pathsep.join(dict.fromkeys(path for path in custom_paths if path and os.path.isdir(path)))

    allow_zero_gpus = False

    def _build_launch_plan(self, job_meta: dict, fl_ctx: FLContext, *, runtime=None) -> LaunchPlan:
        if not isinstance(job_meta, dict):
            raise SlurmLauncherError("job_meta must be a mapping")
        job_id = job_meta.get(JobConstants.JOB_ID)
        try:
            check_job_id(job_id)
        except ValueError as e:
            raise SlurmLauncherError("invalid job ID") from e
        if "\n" in job_id or "\r" in job_id:
            raise SlurmLauncherError("invalid job ID")
        site_name = _require_string(fl_ctx.get_identity_name(), "site identity")
        workspace = fl_ctx.get_prop(FLContextKey.WORKSPACE_OBJECT)
        if not isinstance(workspace, Workspace):
            raise SlurmLauncherError(f"missing {FLContextKey.WORKSPACE_OBJECT} in FLContext")
        if os.path.realpath(workspace.get_root_dir()) != self.config.workspace_path:
            raise SlurmLauncherError("FLContext workspace does not match configured Slurm workspace_path")
        run_dir = _validate_run_dir(self.config.workspace_path, workspace.get_run_dir(job_id))
        try:
            require_job_cert(fl_ctx, run_dir)
        except JobCertError as e:
            raise SlurmLauncherError(str(e)) from e

        raw_job_args = fl_ctx.get_prop(FLContextKey.JOB_PROCESS_ARGS)
        if not isinstance(raw_job_args, dict) or not raw_job_args:
            raise SlurmLauncherError(f"missing {FLContextKey.JOB_PROCESS_ARGS} in FLContext")
        connection_entry = raw_job_args.get(JobProcessArgs.PARENT_CONN_SEC, (None, "clear"))
        if not isinstance(connection_entry, (tuple, list)) or len(connection_entry) != 2:
            raise SlurmLauncherError(f"malformed {JobProcessArgs.PARENT_CONN_SEC} in JOB_PROCESS_ARGS")
        process_connection_security = _require_string(connection_entry[1], f"{JobProcessArgs.PARENT_CONN_SEC} value")
        if process_connection_security not in ("clear", "mtls"):
            raise SlurmLauncherError("Slurm job launch requires clear or mTLS parent connection security")
        job_args = _rewrite_parent_url(
            raw_job_args,
            parent_host=self.config.parent_host,
            internal_port=self.config.internal_port,
        )
        parent_scheme = urlsplit(str(job_args[JobProcessArgs.PARENT_URL][1])).scheme
        secure_mode = fl_ctx.get_prop(FLContextKey.SECURE_MODE, False)
        if secure_mode and parent_scheme != SHARED_FILE_SCHEME and process_connection_security != "mtls":
            raise SlurmLauncherError(
                "secure mode requires an mTLS parent connection for Slurm jobs: configure the client's internal "
                "listener (listening_host) with scheme stcp and connection security mtls"
            )
        if (parent_scheme == "stcp") != (process_connection_security == "mtls"):
            raise SlurmLauncherError("parent URL scheme does not match parent connection security")

        study = job_meta.get(JobMetaKey.STUDY.value)
        if study is not None:
            study = _require_string(study, "study name")
        runtime = self._load_study_runtime(study) if runtime is None else runtime
        job_spec = _mapping_or_empty(
            get_job_launcher_spec(job_meta, site_name, "slurm"), f"Slurm spec for site '{site_name}'"
        )
        # AppDeployer classifies a selected Slurm image as BYOC and authorizes it
        # before the locally deployed job reaches this launcher.
        job_image = job_spec.get("image")
        sandbox, image, python_path, setup, directives = self._effective_study_values(runtime, job_image)
        resources = _resolve_resources(
            job_meta,
            site_name,
            sandbox,
            self.config.pending_timeout,
            spec=job_spec,
            allow_zero_gpus=self.allow_zero_gpus,
        )
        additional_node_command, node_app_dir = _resolve_additional_node_command(
            job_spec,
            resources.nodes,
            workspace,
            job_id,
            run_dir,
            self.SUPPORTS_ADDITIONAL_NODE_COMMAND,
        )
        study_env, secret_env = self._study_environment(runtime)
        secret_env.update(get_credential_env(job_args))
        mounts = list(self._study_mounts(runtime)) if sandbox != "none" else []
        if sandbox != "none":
            parent_mount = _file_parent_mount(str(job_args[JobProcessArgs.PARENT_URL][1]), self.config.workspace_path)
            if parent_mount:
                if any(_paths_overlap(parent_mount.destination, mount.destination) for mount in mounts):
                    raise SlurmLauncherError("shared-file parent directory overlaps a study mount destination")
                mounts.append(parent_mount)
            attach_mount = (
                _file_attach_mount(workspace, self.config.workspace_path) if self.SUPPORTS_CLIENT_API_ATTACH else None
            )
            if attach_mount and attach_mount != parent_mount:
                if any(_paths_overlap(attach_mount.destination, mount.destination) for mount in mounts):
                    raise SlurmLauncherError("shared-file Client API Attach root overlaps another mount destination")
                mounts.append(attach_mount)
        return LaunchPlan(
            job_id=job_id,
            site_name=site_name,
            run_dir=run_dir,
            exe_module=self.EXE_MODULE,
            module_args=self.get_module_args(job_args),
            resources=resources,
            directives=directives,
            sandbox=sandbox,
            image=image,
            setup=setup,
            study_env=study_env,
            study_secret_env=secret_env,
            mounts=tuple(mounts),
            python_path=python_path,
            python_env=self._python_environment(workspace, job_id),
            forward_env=self.config.forward_env,
            additional_node_command=additional_node_command,
            node_app_dir=node_app_dir,
        )

    def launch_job(self, job_meta: dict, fl_ctx: FLContext) -> JobHandleSpec:
        if self.manager is None:
            raise SlurmLauncherError("nested Slurm job launch is unavailable inside a Slurm child process")
        plan = self._build_launch_plan(job_meta, fl_ctx)
        return self.manager.launch(plan)

    def handle_event(self, event_type: str, fl_ctx: FLContext):
        if self.manager is None:
            return
        if event_type == EventType.SYSTEM_BOOTSTRAP:
            self.manager.initialize()
        elif event_type == EventType.BEFORE_JOB_LAUNCH:
            add_launcher(self, fl_ctx)
        elif event_type == EventType.SYSTEM_END:
            self.manager.shutdown()


_GPU_ENV = ("CUDA_VISIBLE_DEVICES", "HIP_VISIBLE_DEVICES", "ROCR_VISIBLE_DEVICES", "NVIDIA_VISIBLE_DEVICES")


class ClientSlurmJobLauncher(SlurmJobLauncher):
    """Launch a resident compute CJ or a coordinator with disposable workers."""

    EXE_MODULE = "nvflare.private.fed.app.client.worker_process"
    SUPPORTS_ADDITIONAL_NODE_COMMAND = True
    SUPPORTS_CLIENT_API_ATTACH = True

    def get_module_args(self, job_args: dict) -> tuple:
        return _module_args(job_args, get_client_job_args(include_exe_module=False, include_set_options=True))

    def __init__(self, *, cj_cpu_cores=1, cj_memory_mb=1024, cj_gpu_count=0, task_shutdown_timeout=30.0, **kwargs):
        super().__init__(**kwargs)
        self.task_shutdown_timeout = _require_positive_number(task_shutdown_timeout, "task_shutdown_timeout")
        from nvflare.apis.task_launcher_spec import TaskResourceRequest

        request = TaskResourceRequest(cj_cpu_cores, cj_memory_mb, cj_gpu_count)
        if request.cpu_cores is None or not float(request.cpu_cores).is_integer():
            raise ValueError("Slurm CJ CPU request must be whole cores")
        self.cj_resources = JobResources(
            cpus_per_node=int(request.cpu_cores),
            mem_per_node=request.memory_mb,
            gpus_per_node=request.gpu_count,
            pending_timeout=self.config.pending_timeout,
        )

    def _cj_resources_for_job(self, job_meta, site_name):
        requested = get_cj_resource_spec(job_meta, site_name)
        if requested.get("mem_per_gpu_in_GiB", 0):
            raise ValueError("Slurm CJ allocations cannot enforce per-GPU memory requirements")
        # Slurm admits whole cores. Allocate at least the requested CPU share.
        cpus = math.ceil(requested.get("num_of_cpus", self.cj_resources.cpus_per_node))
        memory = (
            portable_memory_to_mib(requested["memory"]) if "memory" in requested else self.cj_resources.mem_per_node
        )
        return replace(
            self.cj_resources,
            cpus_per_node=cpus,
            mem_per_node=memory,
            gpus_per_node=requested.get("num_of_gpus", self.cj_resources.gpus_per_node),
        )

    def _prepare_launch(self, job_meta, fl_ctx):
        if not isinstance(job_meta, dict):
            raise SlurmLauncherError("job_meta must be a mapping")
        workspace = fl_ctx.get_prop(FLContextKey.WORKSPACE_OBJECT)
        if not isinstance(workspace, Workspace):
            raise SlurmLauncherError(f"missing {FLContextKey.WORKSPACE_OBJECT} in FLContext")
        if os.path.realpath(workspace.get_root_dir()) != self.config.workspace_path:
            raise SlurmLauncherError("FLContext workspace does not match configured Slurm workspace_path")
        job_id = job_meta.get(JobConstants.JOB_ID)
        try:
            check_job_id(job_id)
        except ValueError as error:
            raise SlurmLauncherError("invalid job ID") from error
        config = (
            ConfigService.load_config_dict(workspace.get_client_app_config_file_path(job_id), raise_exception=False)
            or {}
        )
        lifetime = get_client_execution_lifetime(config)
        validate_cj_execution_lifetime(job_meta, fl_ctx.get_identity_name(), lifetime)
        if lifetime == ExecutionLifetime.JOB:
            return super()._build_launch_plan(job_meta, fl_ctx), None
        from nvflare.app_opt.job_launcher.slurm.task_launcher import _SlurmTaskBackend
        from nvflare.app_opt.job_launcher.slurm.task_policy import TASK_LAUNCHER_PATH, component_args, component_path

        data = ConfigService.load_config_dict(workspace.get_resources_file_path())
        launcher_config = data.get("task_execution", {}).get("launcher", {})
        if component_path(launcher_config) != TASK_LAUNCHER_PATH:
            raise ValueError("Slurm CPU CJ requires the exact site SlurmTaskLauncher")
        task_launcher = _SlurmTaskBackend(**component_args(launcher_config))
        task_launcher.validate_site_config(data)
        runtime = self._load_study_runtime(job_meta.get(JobMetaKey.STUDY.value))
        task_launcher.bind_job(job_id, fl_ctx.get_identity_name(), workspace, job_meta, runtime=runtime)
        cj_resources = self._cj_resources_for_job(job_meta, fl_ctx.get_identity_name())
        # The original metadata stays intact on disk and in the CJ. This copy
        # is solely the physical CJ allocation, never the compute request.
        cj_meta = copy.deepcopy(job_meta)
        cj_meta[JobMetaKey.RESOURCE_SPEC.value] = {}
        compute = get_job_launcher_spec(job_meta, fl_ctx.get_identity_name(), "slurm")
        timing = {key: compute[key] for key in ("time", "pending_timeout") if key in compute}
        if "pending_timeout" in timing:
            timing["pending_timeout"] = min(timing["pending_timeout"], self.config.pending_timeout)
        cj_meta[JobMetaKey.JOB_LAUNCHER_SPEC.value] = {fl_ctx.get_identity_name(): {"slurm": timing}}
        plan = super()._build_launch_plan(cj_meta, fl_ctx, runtime=runtime)
        if plan.sandbox != "none" or plan.image:
            raise ValueError("Slurm task CJ requires the bare shared-filesystem profile")
        environment = dict(plan.study_env)
        if cj_resources.gpus_per_node == 0:
            environment.update({name: "none" if name == "NVIDIA_VISIBLE_DEVICES" else "" for name in _GPU_ENV})
        return (
            replace(
                plan,
                clear_gres=True,
                resources=replace(
                    cj_resources, time_limit=plan.resources.time_limit, pending_timeout=plan.resources.pending_timeout
                ),
                study_env=environment,
                additional_node_command=(),
                node_app_dir=None,
                execution_lifetime=ExecutionLifetime.TASK,
            ),
            task_launcher,
        )

    def _build_launch_plan(self, job_meta, fl_ctx):
        return self._prepare_launch(job_meta, fl_ctx)[0]

    def launch_job(self, job_meta, fl_ctx):
        if self.manager is None:
            raise SlurmLauncherError("nested Slurm job launch is unavailable inside a Slurm child process")
        plan, backend = self._prepare_launch(job_meta, fl_ctx)
        if backend is None:
            return self.manager.launch(plan)
        from nvflare.app_opt.job_launcher.slurm.task_service import ENV_TASK_OWNER, ENV_TASK_TOKEN, SlurmTaskService

        cell = fl_ctx.get_engine().get_cell()
        service = SlurmTaskService.get_or_create(cell)
        self._task_service = service
        token = secrets.token_hex(32)
        owner = service.add_job(backend, plan.job_id, plan.site_name, token)
        plan = replace(
            plan,
            study_secret_env={
                **plan.study_secret_env,
                ENV_TASK_OWNER: cell.get_fqcn(),
                ENV_TASK_TOKEN: token,
            },
        )
        try:
            handle = self.manager.launch(plan)
        except BaseException:
            owner.release()
            raise
        owner.attach_cj(handle)
        result = JobHandleWithTaskWorkers(handle, owner, self.task_shutdown_timeout)
        try:
            publish_job_handle(result, fl_ctx)
        except BaseException:
            result.terminate()
            result.wait()
            raise
        return result

    def handle_event(self, event_type, fl_ctx):
        if event_type == EventType.SYSTEM_BOOTSTRAP and self.manager is not None and self.config.sandbox == "none":
            self.log_warning(
                fl_ctx,
                "Slurm bare profile requires trusted job code: jobs share the site's UID and "
                "workspace and can access site private keys and scheduler credentials. Secure transport "
                "does not provide filesystem or credential isolation.",
            )
        super().handle_event(event_type, fl_ctx)
        if event_type == EventType.SYSTEM_END:
            service = getattr(self, "_task_service", None)
            if service is not None:
                service.shutdown(timeout=self.task_shutdown_timeout)


class ServerSlurmJobLauncher(SlurmJobLauncher):
    EXE_MODULE = "nvflare.private.fed.app.server.runner_process"

    def get_module_args(self, job_args: dict) -> tuple:
        return _module_args(job_args, get_server_job_args(include_exe_module=False, include_set_options=True))
