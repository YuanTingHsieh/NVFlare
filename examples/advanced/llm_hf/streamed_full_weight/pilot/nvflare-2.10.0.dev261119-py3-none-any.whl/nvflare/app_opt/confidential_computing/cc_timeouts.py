# Copyright (c) 2026, NVIDIA CORPORATION.  All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Shared token-generation budget defaults for provisioning and CCManager."""

import math

MANAGER_TIMEOUT_DEFAULTS = {
    "registration_token_timeout": 300.0,
    "refresh_token_timeout": None,
    "get_token_request_timeout": 45.0,
}


def resolve_token_timeouts(
    registration_token_timeout=300.0, refresh_token_timeout=None, get_token_request_timeout=45.0
):
    values = {
        "registration_token_timeout": registration_token_timeout,
        "get_token_request_timeout": get_token_request_timeout,
    }
    # Validate before deriving a budget: bool, NaN, infinity and strings must
    # not silently acquire a valid default through min() or arithmetic.
    for name, value in values.items():
        _validate_timeout(name, value)
    if refresh_token_timeout is None:
        refresh_token_timeout = min(30.0, get_token_request_timeout / 2)
    _validate_timeout("refresh_token_timeout", refresh_token_timeout)
    if get_token_request_timeout <= refresh_token_timeout:
        raise ValueError("get_token_request_timeout must exceed refresh_token_timeout")
    values["refresh_token_timeout"] = refresh_token_timeout
    return values


def _validate_timeout(name, value):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
        raise ValueError(f"{name} must be finite and positive")
