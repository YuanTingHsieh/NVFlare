# Copyright (c) 2026, NVIDIA CORPORATION.  All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Trusted Slurm profile matching and task-resource resolution."""

from dataclasses import replace

from nvflare.apis.task_launcher_spec import TaskResourceRequest
from nvflare.app_opt.job_launcher.slurm.config import _require_int
from nvflare.app_opt.job_launcher.slurm.launcher import _resolve_resources
from nvflare.job_config.task_execution import reject_job_gpu_reservation
from nvflare.utils.job_launcher_utils import (
    get_compute_resource_manager_spec,
    get_job_launcher_spec,
    get_launcher_resource_spec,
    get_portable_resource_spec,
    validate_portable_resource_conflicts,
)

TASK_LAUNCHER_PATH = "nvflare.app_opt.job_launcher.slurm.task_launcher.SlurmTaskLauncher"
CJ_LAUNCHER_PATH = "nvflare.app_opt.job_launcher.slurm.launcher.ClientSlurmJobLauncher"
DOCKER_CJ_LAUNCHER_PATH = "nvflare.app_opt.job_launcher.docker_launcher.ClientDockerJobLauncher"
PROCESS_CJ_LAUNCHER_PATH = "nvflare.app_common.job_launcher.client_process_launcher.ClientProcessJobLauncher"


def component_args(config):
    if not isinstance(config, dict):
        raise ValueError("Slurm site component must be a dictionary")
    args = config.get("args", {})
    if not isinstance(args, dict):
        raise ValueError("Slurm site component args must be a dictionary")
    args = args.get("class_attributes", args)
    if not isinstance(args, dict):
        raise ValueError("Slurm site class_attributes must be a dictionary")
    return args


def component_path(config):
    if not isinstance(config, dict):
        raise ValueError("Slurm site component must be a dictionary")
    path = config.get("path", config.get("class_path"))
    # deploy prepare uses the public package re-export of this exact class.
    if path == "nvflare.app_opt.job_launcher.slurm.ClientSlurmJobLauncher":
        return CJ_LAUNCHER_PATH
    return path


def validate_slurm_site(launcher, site_config):
    from nvflare.app_opt.job_launcher.slurm.launcher import ClientSlurmJobLauncher

    if not isinstance(site_config, dict) or not isinstance(site_config.get("components", []), list):
        raise ValueError("Slurm canonical site configuration must contain a component list")
    components = site_config.get("components", [])
    matches = [item for item in components if str(component_path(item)).endswith("JobLauncher")]
    runtimes = {PROCESS_CJ_LAUNCHER_PATH: "process", DOCKER_CJ_LAUNCHER_PATH: "docker", CJ_LAUNCHER_PATH: "slurm"}
    if len(matches) != 1 or component_path(matches[0]) not in runtimes:
        raise ValueError(
            "Slurm task profile requires exactly one supported Process, Docker or Slurm client job launcher; "
            "different CP/CJ job launchers cannot be combined"
        )
    runtime = runtimes[component_path(matches[0])]
    if runtime == "process":
        return runtime
    if runtime == "docker":
        from nvflare.app_opt.job_launcher.docker_launcher import ClientDockerJobLauncher

        args = dict(component_args(matches[0]))
        # Ordinary Docker sites obtain this from CP's environment. CJ has no
        # parent-only environment, so validate against the native site path.
        args["workspace"] = args.get("workspace") or launcher.manager.config.workspace_path
        cj = ClientDockerJobLauncher(**args)
        cj._validate_task_coordinator_profile(launcher.manager.config.workspace_path, network=cj.network)
        return runtime
    cj = ClientSlurmJobLauncher(**component_args(matches[0]))
    if cj.config.workspace_path != launcher.manager.config.workspace_path or cj.config.sandbox != "none":
        raise ValueError("Slurm CP/CJ/task profile requires the same bare shared workspace")
    if cj.config.image:
        raise ValueError("Slurm task profile does not support a CJ container image")
    return runtime


def task_resources(launcher, meta, site_name):
    """Resolve native/default resources without retaining whole-job GPU tokens."""
    validate_portable_resource_conflicts(meta)
    reject_job_gpu_reservation(meta, site_name)
    compute_admission = get_compute_resource_manager_spec(meta, site_name)
    unsupported = set(compute_admission) - {"num_of_gpus", "mem_per_gpu_in_GiB"}
    if unsupported or compute_admission.get("mem_per_gpu_in_GiB", 0):
        raise ValueError("Slurm task allocations cannot enforce custom resource-manager or GPU-memory requirements")
    portable = get_portable_resource_spec(meta, site_name)
    native = get_job_launcher_spec(meta, site_name, "slurm")
    if native.get("nodes", 1) != 1 or native.get("additional_node_command"):
        raise ValueError("Slurm task profile supports one node without additional_node_command")
    if native.get("image"):
        raise ValueError("Slurm task profile does not support container images")
    default = launcher.resources
    # RM admission drops zero GPU counts; preserve an explicit legacy zero.
    compute_gpus = get_launcher_resource_spec(meta, site_name, "process").get(
        "num_of_gpus", compute_admission.get("num_of_gpus", default.gpu_count)
    )
    gpu_count = native.get("gpus_per_node", portable.get("num_of_gpus", compute_gpus))
    _require_int(gpu_count, "gpus_per_node", 0)
    spec = {"cpus_per_node": int(default.cpu_cores or 1), **native}
    if default.memory_mb is not None:
        spec.setdefault("mem_per_node", default.memory_mb)
    spec["gpus_per_node"] = gpu_count
    resolved = _resolve_resources(
        meta, site_name, "none", launcher.manager.config.pending_timeout, spec=spec, allow_zero_gpus=True
    )
    if resolved.cpus_per_node is None or resolved.mem_per_node is None:
        raise ValueError("Slurm task allocations require CPU and memory requests, including GPU tasks")
    return replace(resolved, gpus_per_node=gpu_count)


def resource_request(resources):
    return TaskResourceRequest(resources.cpus_per_node, resources.mem_per_node, resources.gpus_per_node or 0)
